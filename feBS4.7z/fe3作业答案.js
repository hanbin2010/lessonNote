var log = console.log.bind(console)

var ensure = function(condition, message) {
    // condition 是布尔值
    // message 是 string, condition 不成立的时候被输出
    if (!condition) {
        console.log(message)
    } else {
        console.log('测试成功')
    }
}

var ensureEqual = function(a, b, message) {
    if (a != b) {
        console.log(`${message}, (${a}) 不等于 (${b})`)
    } else {
        console.log('测试成功')
    }
}

var floatEqual = function(a, b) {
    var delta = 0.0001
    return Math.abs(a - b) < delta
}


// 例子 1
// 求数组的和
var sum = function(array) {
    // 先设置一个变量用来存数组的和
    var s = 0
    for (var i = 0; i < array.length; i++) {
        // 用变量 n 保存元素的值
        var n = array[i]
        // 累加到变量 s
        s = s + n
    }
    // 循环结束, 现在 s 里面存的是数组中所有元素的和了
    return s
}

// 作业 1
// 参数是一个只包含数字的 array
// 求 array 的乘积
// 函数定义是
var product = function(array) {
    // 先设置一个变量用来存数组的结果
    var s = 1
    for (var i = 0; i < array.length; i++) {
        // 用变量 n 保存元素的值
        var n = array[i]
        // 累乘到变量 s
        s = s * n
    }
    // 循环结束, 现在 s 里面存的是数组中所有元素的乘积了
    return s
}

var testProduct = function() {
    var numbers = [1, 2, 3, 4]
    var value = 24
    //
    ensure(product(numbers) == value, '测试出错1')
    ensure(product([1]) == 1, '测试出错2')
    ensure(product([0, 1, 2]) == 0, '测试出错3')
}

// testProduct()


// 作业 2
// 返回一个数的绝对值
// 函数定义是
var abs = function(n) {
    if (n < 0) {
        n = -n
    }
    return n
}

var testAbs = function() {
    ensure(abs(0) == 0, 'abs error, 0')
    ensure(abs(2) == 2, 'abs error, 2')
    ensure(abs(-3) == 3, 'abs error, 3')

    log('*** abs 测试成功')
}

// testAbs()

// 作业 3
// 参数是一个只包含数字的 array
// 求 array 中所有数字的平均数
// 函数定义是
var average = function(array) {
    var n = array.length
    var s = sum(array)
    return s / n
}

var testAverage = function() {
    ensure(average([1, 2, 3]) == 2, 'average 2')
    ensure(average([1, 2, 3, 5]) == 2.75, 'average 2.75')
    var equal = floatEqual(average([5, 2, 3]), 3.3333)
    ensure(equal, 'average 3.33')

    log('*** average 测试成功')
}

// 注意, 下面这种就是反例,
// 不符合最外面只有函数的定义这种形式
// a = [1, 2, 3]
// log('sum', sum(a))


/*
注意 下面几题中的参数 op 是 operator(操作符) 的缩写

作业 8
实现 apply 函数
参数如下
op 是 string 类型, 值是 '+' '-' '*' '/' 其中之一
a b 分别是 2 个数字
根据 op 对 a b 运算并返回结果(加减乘除)
*/
var apply = function(op, a, b) {
    if (op == '+') {
        return a + b
    }
    if (op == '-') {
        return a - b
    }
    if (op == '*') {
        return a * b
    }
    if (op == '/') {
        return a / b
    }
}

var applyList = function(op, oprands) {
    var s = oprands[0]
    for (var i = 1; i < oprands.length; i++) {
        var n = oprands[i]
        s = apply(op, s, n)
    }
    return s
}

var testApply = function() {
    ensureEqual(apply('+', 1, 2), 4, 'apply error 1')
    ensureEqual(apply('-', 1, 2), -1, 'apply error 2')
}

var testApplyList = function() {
    ensureEqual(applyList('+', [1, 2, 3, 4]), 10, 'apply list 111')
    ensureEqual(applyList('-', [3, 4, 2, 1]), -4, 'apply list 222')
    ensureEqual(applyList('*', [3, 4, 2, 1]), 24, 'apply list 333')
    ensureEqual(applyList('/', [24, 4, 2, 3]), 1, 'apply list 444')
}

var __main = function() {
    // testAbs()
    // testAverage()
    // testApply()
    testApplyList()
}

__main()
