// 今天上课的主要内容
//
// 1. HTTP(Hyper-Text Transpotation Protocol) 协议
// 2. AJAX
// 3. BOM（Browser Object Model 浏览器对象模型）
