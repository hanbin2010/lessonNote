/*
此为第 1 课的上课内容, 请自行完成


预习内容
===
使用 chrome 或者 firefox 浏览器打开如下页面
http://107.170.232.91/

页面上边是写代码的编辑窗口
页面下边是运行代码的结果


代码编辑窗口中, 可以使用 2 个预定义的语句
每条语句独占一行



画布中有一个黑色三角箭头
forward(100) 用来把三角箭头往前移动 100 像素
right(90) 用来把三角箭头往右旋转 90 度
三角箭头在一开始的时候朝右

例子 1
画一个边长为 101 像素的正三角形的代码如下
注意
1, 一条语句一行
2, 括号必须是英文字符(使用中文字符会报错误)

forward(101)
right(120)
forward(101)
right(120)
forward(101)
right(120)



根据例子 1 完成下面的题目
不会写的题目先记下来, 上课重点听
--------
题目
--------

作业 1
画一个边长为 10 像素的正三角形
forward(10)
right(120)
forward(10)
right(120)
forward(10)
right(120)

作业 2
画一个边长为 99 像素的正方形
var x = 100
var degree = 90

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)

作业 3
画一个长宽分别为 168, 99 像素的矩形
var w = 168
var h = 99
var degree = 90

forward(w)
right(degree)
forward(h)
right(degree)
forward(w)
right(degree)
forward(h)
right(degree)


作业 4
画一个边长为 33 像素的正三角形
var x = 33
var degree = 120

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)

作业 5
画一个边长为 106 像素的正方形
var x = 106
var degree = 90

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)

作业 6
画一个长宽分别为 68, 59 像素的矩形
var w = 68
var h = 59
var degree = 90

forward(w)
right(degree)
forward(h)
right(degree)
forward(w)
right(degree)
forward(h)
right(degree)

作业 7
画一个边长为 79 的正五边形
提示, 往右旋转 72 度
var x = 79
var degree = 72

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)

作业 8
画一个边长为 63 的正六边形
提示, 往右旋转 60 度

正 n 边形的内角和等于 (n - 2) * 180
JavaScript 中的四则运算如下
* 代表乘号
/ 代表除号

四则运算是有优先级的, + - 低于 * /

var x = 63
var n = 6
var 内角 = (n - 2) * 180 / n
var degree = 180 - 内角

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)


作业 9
画一个边长为 159 的正七边形
提示, 往右旋转 52 度
var x = 159
var n = 7
var 内角 = (n - 2) * 180 / n
var degree = 180 - 内角

forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)

作业 10
画一个边长为 93 的正十边形
提示, 往右旋转 36 度

// 注释
//
/*
这是多行注释
可以换行
*/

// 复制粘贴太机械
// 有没有更优雅的办法呢?

var x = 93
var n = 10
var 内角 = (n - 2) * 180 / n
// degree 是转角
var degree = 180 - 内角

forward(x)      // 前进
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)
forward(x)
right(degree)


// atom 输入 Ctrl + \ 可以关闭/ 打开侧边栏

// 复制粘贴太机械
// 有没有更优雅的办法呢?
var x = 93
var n = 10
var 内角 = (n - 2) * 180 / n
var degree = 180 - 内角

// 下面是循环的写法
// 首先定义一个变量用于计算循环的次数, 通常为 i j k, 也可以是 a, b, c
var i = 0
// 小括号之内是条件
// 当条件成立的时候, 执行花括号内的语句
// 否则, 结束循环
while (i < n) {
    forward(x)
    right(degree)
    // 注意, 在 while 循环内, 一定要改变 i 的值
    // 否则循环永远不会结束(无限循环)
    i = i + 1
}


// 函数
// 函数是用来消除大段重复代码的功能
// 主流的语言都有函数这个特性
// 函数是一段代码的集合, 用于重复使用一段代码
// 下面用例子演示定义并使用函数的方式


// 定义一个函数, 用来画一个边长为 100 的正三角形
// 可以看到, 函数和数字是一样的, 可以被赋值给 变量
var 三角形 = function() {
    var x = 100
    var n = 3
    var 内角 = (n - 2) * 180 / n
    var degree = 180 - 内角

    var i = 0
    while (i < n) {
        forward(x)
        right(degree)
        i = i + 1
    }
}

// 上面是定义三角形函数的方式, 下面就可以使用了
// 注意, 程序是按照顺序执行的, 所以定义要在使用之前
// 函数名 加上一对 括号(英文括号) 就表示调用函数(调用即为使用)
三角形()

// 函数和其他普通的值一样, 可以被赋值给另外一个变量
var sjjc = 三角形
sjjc()


// 函数可以有一个叫做参数的概念来增加灵活性
// 函数的参数相当于微波炉的旋钮
// win32 api 就是一套非常繁复的设计
// 括号中的 x 就是参数
var 三角形 = function(x) {
    // var x = 100
    var n = 3
    var 内角 = (n - 2) * 180 / n
    var degree = 180 - 内角

    var i = 0
    while (i < n) {
        forward(x)
        right(degree)
        i = i + 1
    }
}
三角形(10)
三角形(50)
三角形(100)


// 函数可以支持多个参数, 不同参数用逗号分隔
// 函数的默认参数(这是新功能, 只有在新版本的浏览器才能支持)
var polygon = function(边长, bmuu=3) {
    // var x = 100
    var n = bmuu
    var 内角 = (n - 2) * 180 / n
    var degree = 180 - 内角

    var i = 0
    while (i < n) {
        forward(边长)
        right(degree)
        i = i + 1
    }
}

polygon(100)
polygon(100, 4)

// 变量名命名规则(函数名也是变量名)
// 变量名只能包括 字母(汉字名也算字母), 下划线(_), 美元符号($), 数字
// 变量名不能以数字开头
// 变量名大小写敏感(a A 是两个不同的变量)
// 只有在现代的 JavaScript 中, 才能使用汉字作为合法的变量名
// 变量名不能是 JavaScript 的保留字(while var function 这样的就是保留字
// 还有很多保留字, 但是你现在不需要关心)

*/
