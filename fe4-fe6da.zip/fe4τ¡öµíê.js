var log = console.log.bind(console)

var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if (!condition) {
        log('*** 测试失败:', message)
    } else {
        log('||| 测试成功')
    }
}

var lower = 'abcdefghijklmnopqrstuvwxyz'
var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'



// 作业 1
// 10 分钟做不出就看提示
//
var find = function(s1, s2) {
    /*
    s1 s2 都是 string
    但 s2 的长度是 1

    返回 s2 在 s1 中的下标, 从 0 开始, 如果不存在则返回 -1
    */
    // 遍历 s1
    for (var i = 0; i < s1.length; i++) {
        var s = s1[i]
        // 判断当前下标的字符串是否和 s2 相等
        if (s2 == s) {
            // 如果相等，就返回当前的下标
            return i
        }
    }
    // 比较完所有 s1 中的字符，都没有找到 s2，所以就返回 -1
    return -1
}

// 测试函数, 自行实现
var test_find = function() {
    ensure(find('hello', 'a') == -1, 'find 1')
    ensure(find('hello', 'e') == 1, 'find 2')
    ensure(find('hello', 'l') == 2, 'find 3')
}


var lowercase = function(s) {
    // 初始化一个空字符串
    var result = ""
    for (var i = 0; i < s.length; i++) {
        // 注意, 这个 find 是你要实现的函数
        var index = find(upper, s[i])
        // 字符串可以用加号拼接, 不明白可以 log 一下
        result += lower[index]
    }
    return result
}

/*
作业 2

定义一个函数
参数是一个字符串 s
返回大写后的字符串
注意, 假设 s 字符串全是小写字母

注意, 自行实现测试函数, 之后的题目都要求自行实现测试函数
*/

var uppercase = function(s) {
    // 初始化一个空字符串
    var result = ""
    for (var i = 0; i < s.length; i++) {
        // 注意, 这个 find 是你要实现的函数
        var index = find(lower, s[i])
        // 字符串可以用加号拼接, 不明白可以 log 一下
        result += upper[index]
    }
    return result
}

var test_uppercase = function() {
    ensure(uppercase('hello') == 'HELLO', 'uppercase 1')
    ensure(uppercase('gua') == 'GUA', 'uppercase 2')
}

/*
作业 3

实现 lowercase1
它能正确处理带 小写字母 的字符串

*/
var lowercase1 = function(s) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    // 初始化一个空字符串
    var result = ""
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(upper, c)
        if (index == -1) {
            // 没有在 upper 里面 find 到，说明这是一个小写字母
            // 这里也可以用 upper.includes(c) 来判断 c 是否是一个大写字母
            result += c
        } else {
            // 字符串可以用加号拼接, 不明白可以 log 一下
            result += lower[index]
        }
    }
    return result
}

// 字符串不能使用下标来赋值
// 只能拼接起来生成一个新的字符串

var test_lowercase1 = function() {
    ensure(lowercase1('heLLo') == 'hello', 'lowercase1 1')
    ensure(lowercase1('gua') == 'gua', 'lowercase1 2')
    ensure(lowercase1('GW') == 'gw', 'lowercase1 3')
}



/*
作业 4

实现 uppercase1
它能正确处理带 大写字母 的字符串
*/
var uppercase1 = function(s) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    // 初始化一个空字符串
    var result = ""
    log(`debug result start, (${result})`)
    for (var i = 0; i < s.length; i++) {
        // 注意, 这个 find 是你要实现的函数
        var c = s[i]
        var index = find(lower, c)
        // 说明 c 不在 upper 中
        log('index == -1', index, index == -1, c)
        // 如果 index 为 -1, 说明 c 不是 lower 中的字母
        // 说明 c 是大写字母
        if (index == -1) {
            // 如果 c 是大写字母, 就应该直接拼接 c
            result += c
        } else {
            // 字符串可以用加号拼接, 不明白可以 log 一下
            // 进入这个分支, 说明是小写字母,
            // 要把小写字母转成大写字母
            result += upper[index]
        }
    }
    log('debug result', result)
    return result
}

var test_uppercase1 = function() {
    ensure(uppercase1('helLo') == 'HELLO', 'uppercase1 1')
    ensure(uppercase1('gUA') == 'GUA', 'uppercase1 2')
}

/*
作业 5
实现一个叫 凯撒加密 的加密算法, 描述如下
对于一个字符串, 整体移位, 就是加密
以右移 1 位为例
原始信息 'afz' 会被加密为 'bga'
实现 encode1 函数, 把明文加密成密码并返回
右移 1 位

注意:
    s 是一个只包含小写字母的字符串
*/
var encode1 = function(s) {
    /*
    1. 遍历 s
    2. 针对 s 里面的每一个字符 c，我们找到下标
    3. 让 index + 1，找到相应的字符，存入到一个结果变量中
    4. 如果 index + 1 后是 26，则变成 0，这个用来处理 z -> a 的情况
    5. 返回结果
    */
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        // var newIndex = index + 1
        // if (newIndex == 26) {
        //     newIndex = 0
        // }
        var newIndex = (index + 1) % lower.length
        result += lower[newIndex]
    }
    return result
}

var test_encode1 = function() {
    ensure(encode1('afz') == 'bga', 'encode1 1')
    ensure(encode1('gw') == 'hx', 'encode1 2')
}

/*
作业 6
实现 decode1 函数, 把作业 5 加密的密码解密为明文并返回

注意:
    s 是一个只包含小写字母的字符串
*/
var decode1 = function(s) {
    // 这是一个很巧妙的思路
    // for (var i = 0; i < lower.length - 1; i++) {
    //     s = encode1(s)
    // }
    // return s

    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        var newIndex = (lower.length + index - 1) % lower.length
        result += lower[newIndex]
    }
    return result
}

var test_decode1 = function() {
    ensure(decode1('bga') == 'afz', 'decode1 1')
    ensure(decode1('hx') == 'gw', 'decode1 2')
}

/*
作业 7
实现 encode2
多了一个参数 shift 表示移的位数

注意:
    s 是一个只包含小写字母的字符串

*/
var encode2 = function(s, shift) {
    /*
    1. 遍历 s
    2. 针对 s 里面的每一个字符 c，我们找到下标
    3. 让 index + shift，找到相应的字符，存入到一个结果变量中
    4. 如果 index + shift 后超过 26，则取 26 的余数
    5. 返回结果
    */
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        var newIndex = (index + shift) % lower.length
        result += lower[newIndex]
    }
    return result
}

var test_encode2 = function() {
    ensure(encode2('afz', 2) == 'chb', 'encode2 1')
    ensure(encode2('gw', 3) == 'jz', 'encode2 2')
}


/*
作业 8
实现 decode2
多了一个参数 shift 表示移的位数

注意:
    s 是一个只包含小写字母的字符串

*/
var decode2 = function(s, shift) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        var newIndex = (lower.length + index - shift) % lower.length
        result += lower[newIndex]
    }
    return result
}

var test_decode2 = function() {
    ensure(decode2('chb', 2) == 'afz', 'decode2 1')
    ensure(decode2('jz', 3) == 'gw', 'decode2 2')
}


/*
作业 9
实现 encode3
多了一个参数 shift 表示移的位数
如果 s 中包含了不是字母的字符, 比如空格或者其他符号, 则对这个字符不做处理保留原样

注意:
    s 是一个只包含小写字母和不是字母的字符的字符串

*/
var encode3 = function(s, shift) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        if (index == -1) {
            result += c
        } else {
            var newIndex = (index + shift) % lower.length
            result += lower[newIndex]
        }
    }
    return result
}
var test_encode3 = function() {
    ensure(encode3('a fz', 2) == 'c hb', 'encode3 1')
    ensure(encode3('g#w', 3) == 'j#z', 'encode3 2')
}


/*
作业 10
实现 decode3
多了一个参数 shift 表示移的位数
如果 s 中包含了不是字母的字符, 比如空格或者其他符号, 则对这个字符不做处理保留原样

注意:
    s 是一个只包含小写字母和不是字母的字符的字符串
*/
var decode3 = function(s, shift) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var index = find(lower, c)
        if (index == -1) {
            result += c
        } else {
            var newIndex = (lower.length + index - shift) % lower.length
            result += lower[newIndex]
        }
    }
    return result
}

var test_decode3 = function() {
    ensure(decode3('ch#b', 2) == 'af#z', 'decode3 1')
    ensure(decode3('j z', 3) == 'g w', 'decode3 2')
}


/*
作业 11
知乎有一个求助题, 破译密码的
链接在此
https://www.zhihu.com/question/28324597
这一看就是凯撒加密...
如果没思路, 可看本文件最后的提示
我把密码放在下面, 请解出原文
*/
var code = 'VRPHWLPHV L ZDQW WR FKDW ZLWK BRX,EXW L KDYH QR UHDVRQ WR FKDW ZLWK BRX'

var decode4 = function(s) {
    var lower = 'abcdefghijklmnopqrstuvwxyz'
    var code = lowercase1(s)

    for (var i = 0; i < lower.length; i++) {
        var result = encode3(code, i)
        log(result)
    }
}

var test_decode4 = function() {
    decode4(code)
}



// 作业 12
// 根据本周天气，绘制柱状图
// 中国本周的每日平均气温, 从周一到周日
var forecast1 = function(temps, space) {
    // 柱壮图里每个图宽 30，间距为 space
    jump(0, 0)
    setHeading(0)

    var width = 30
    for (var i = 0; i < temps.length; i++) {
        var t = temps[i]
        var x = i * (width + space)
        var y = -t
        var h = t
        var w = width
        rect(x, y, w, h)
    }
}

var testForecast1 = function() {
    var temps = [22, 19, 22, 21, 25, 27, 30, 28]
    var space = 10
    forecast1(temps, space)
}


// 作业 13
// 根据本周天气，绘制柱状图
// 中国本周的每日平均气温, 从周一到周日
var forecast2 = function(temps, space, base) {
    // 柱壮图里每个图宽 30，间距为 space
    // 增加一个 base 参数，每个温度都减去 base，可以更好地区分不同温度
    jump(0, 0)
    setHeading(0)

    var width = 30
    for (var i = 0; i < temps.length; i++) {
        var t = temps[i] - base
        var x = i * (width + space)
        var y = -t
        var h = t
        var w = width
        rect(x, y, w, h)
    }
}

var testForecast2 = function() {
    var temps = [22, 19, 22, 21, 25, 27, 30, 28]
    var space = 10
    var base = 15
    forecast2(temps, space, base)
}


// 作业 14
// 绘制坐标轴
var coordinateAxis = function() {
    // 在坐标原点处绘制两条坐标轴
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    jump(x, y)
    setHeading(0)

    var x1 = -(w / 2)
    jump(x1, y)
    forward(w)

    jump(x, y)
    setHeading(90)

    var y1 = h / 2
    jump(x, y1)
    forward(h)
}

var forecast3 = function(temps, space, base) {
    coordinateAxis()
    forecast2(temps, space, base)
}

var testForecast3 = function() {
    var temps = [22, 19, 22, 21, 25, 27, 30, 28]
    var space = 10
    var base = 15
    forecast3(temps, space, base)
}

var __main = function() {
    // test_find()
    // test_uppercase()
    // test_lowercase1()
    // test_encode1()
    // test_decode1()
    // test_encode2()
    // test_decode2()
    // test_encode3()
    // test_decode3()
    // test_decode4()
}

__main()
