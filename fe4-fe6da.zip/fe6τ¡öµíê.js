// 本次作业主要是 string 和 object 相关
//
// string 题目用到的知识还是
// 0, 用下标引用字符串
// 2, 循环
// 3, 选择 (也就是 if)
// 1, 字符串切片
//
// 注意, 提示在文件最末尾
// ============
//
// 请以之前上课中 string 相关的内容作为参考
// 请自行编写测试
//


// 定义我们的 log 函数
var log = console.log.bind(console)


// ======
// 测试
// ======
//
// 定义我们用于测试的函数
// ensure 接受两个参数
// condition 是 bool, 如果为 false, 则输出 message
// 否则, 不做任何处理
var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if (!condition) {
        log('*** 测试失败 {', message)
    } else {
        log('+++ 测试成功')
    }
}


// 作业 1
// 实现函数
// 10分钟做不出来就看提示
var startsWith = function(s1, s2) {
    /*
    s1 是一个字符串
    s2 是一个字符串
    检查 s1 是否以 s2 开头, 返回 true 或者 false

    提示：
        假设 s2 的长度为 len，获取 s1 的前 len 个字符，判断是否与 s2 相等

    分步提示：
        1. 计算出 s2 的长度 len
        2. 使用 slice 获取 s1 的前 len 个字符，结果为 s
        3. 返回 s 与 s2 的比较结果
    */
    var len = s2.length
    var s = s1.slice(0, len)
    return s == s2
}

var testStartsWith = function() {
    ensure(startsWith('guagua', 'guagua'), 'starts with error 1')
    ensure(!startsWith('guagua', 'melon'), 'starts with error 2')
    ensure(!startsWith('melongua', 'gua'), 'starts with error 3')
}



// 作业 2
// 实现函数
// 10 分钟做不出就看提示
var findIn = function(s1, s2) {
    /*
    s1 是一个字符串
    s2 是一个长度为 1 的字符串
    返回参数 s2 在 s1 中第一次出现的下标
    如果 s2 没有在 s1 中出现, 返回 -1

    提示：
        因为 s2 的长度为 1，所以遍历 s1，判断每次遍历的结果是否与 s2 相等

    分步提示：
        1. 定义变量 index，用来表示第一次出现的下标，初始值为 -1
        2. 遍历字符串 s1，判断每次遍历的结果是否等于 s2
            如果相等，把 i 赋值给 index，并且用 break 跳出当前循环
        3. 循环结束后 index 的结果就是第一次出现的下标，返回 index
    */
    var index = -1
    for (var i = 0; i < s1.length; i++) {
        var n = s1[i]
        if (n == s2) {
            index = i
            break
        }
    }
    return index
}

var testFindIn = function() {
    ensure(findIn('guagua', 'g') == 0, 'find in error 1')
    ensure(findIn('guagua', 'm') == -1, 'find in error 2')
    ensure(findIn('melongua', 'g') == 5, 'find in error 3')
}


// 作业 3
// 实现函数
// 10 分钟做不出就看提示
var arrayEquals = function(a, b) {
    if (a.length != b.length) {
        return false
    }
    for (var i = 0; i < a.length; i++) {
        var a1 = a[i]
        var b1 = b[i]
        if (a1 != b1) {
            return false
        }
    }
    return true
}

var findAllIn = function(s1, s2) {
    /*
    s1 是一个字符串
    s2 是一个长度为 1 的字符串
    返回参数 s2 在 s1 中出现的所有下标组成的 array
    如果 s2 没有在 s1 中出现, 返回空数组 []

    提示：
        这道题目和 findIn 比较类型，但是需要记住所有出现的下标，这个就可以用数组来存储了
        数组的判断不能直接用 ==，所以我们要先实现一个 arrayEquals 的函数

    分步提示：
        1. 实现 arrayEquals 函数，有两个参数 a1 和 a2
            a. 首先判断 a1 和 a2 的长度是否相等，如果不相等，直接返回 false
            b. 遍历数组 a1，每次遍历的元素为 a1[i]，判断 a1[i] 与 a2[i] 的值
                如果 a1[i] 与 a2[i] 不相等，直接返回 false
            c. 循环结束后，返回 true
        2. 定义一个数组 result 用来存储所有的下标，初始值为 []
        3. 遍历字符串 s1, 如果遍历的元素与 s2 相等，就把 i 添加到数组 result 中
        4. 循环结束后 result 存储的是所有满足条件的下标，最后返回 result
        5. 在 ensure 函数中比较两个数组使用 arrayEquals 函数
    */
    var result = []
    for (var i = 0; i < s1.length; i++) {
        if (s2 == s1[i]) {
            result.push(i)
        }
    }
    return result
}

var testFindAllIn = function() {
    var test1 = findAllIn('10121320', '1')
    var test2 = findAllIn('10121320', '0')
    var test3 = findAllIn('10121320', '3')
    var test4 = findAllIn('10121320', '9')

    ensure(arrayEquals(test1, [0, 2, 4]), 'find all in error 1')
    ensure(arrayEquals(test2, [1, 7]), 'find all in error 2')
    ensure(arrayEquals(test3, [5]), 'find all in error 3')
    ensure(arrayEquals(test4, []), 'find all in error 4')
}



// 作业 4
// 实现函数
// 10 分钟做不出就看提示
var findAllString = function(s1, s2) {
    /*
    s1 是一个字符串
    s2 是一个字符串, 长度未知, 不一定为 1
    返回参数 s2 在 s1 中出现的下标组成的 array
    如果 s2 没有在 s1 中出现, 返回 []

    提示：
        遍历字符串 s1，每次 slice 一个字符串 s，比较 s 与 s2 的值

    分步提示：
        1. 定义一个数组 result 用来存储所有的下标，初始值为 []
        2. 计算 s2 的长度 len
        3. 遍历字符串 s1, 并且在每次遍历中 slice 一个字符串 s，
            slice 的起始坐标为 i，slice 的长度为 len
            如果遍历的元素与 s2 相等，就把 i 添加到数组 result 中
        4. 循环结束后 result 存储的是所有满足条件的下标，最后返回 result
        5. 在 ensure 函数中比较两个数组使用 arrayEquals 函数
    */
    var len = s2.length
    var list = []
    for (var i = 0; i < s1.length; i++) {
        var s = s1.slice(i, i + len)
        if (s == s2) {
            list.push(i)
        }
    }
    return list
}

var testFindAllString = function() {
    var test1 = findAllString('1012100120', '10')
    var test2 = findAllString('1012100120', '100')
    var test3 = findAllString('1012100120', '3')

    ensure(arrayEquals(test1, [0, 4]), 'find all string error 1')
    ensure(arrayEquals(test2, [4]), 'find all string error 2')
    ensure(arrayEquals(test3, []), 'find all string error 3')
}



// 作业 5
// 实现函数
// 10分钟做不出来就看提示
var endsWith = function(s1, s2) {
    /*
    s1 是一个字符串
    s2 是一个字符串
    检查 s1 是否以 s2 结尾, 返回 true 或者 false

    提示：
        假设 s2 的长度为 len，获取 s1 的最后 len 个字符，判断是否与 s2 相等

    分步提示：
        1. 计算出 s2 的长度 len
        2. 使用 slice 获取 s1 的后 len 个字符，结果为 s
        3. 返回 s 与 s2 的比较结果
    */
    var len = s2.length
    var s = s1.slice(s1.length-len, s1.length)
    return s == s2
}

var testEndsWith = function() {
    ensure(endsWith('guagua', 'guagua'), 'ends with error 1')
    ensure(!endsWith('guagua', 'melon'), 'ends with error 2')
    ensure(endsWith('melongua', 'gua'), 'ends with error 3')
}



// 作业 6
// 实现函数
var max = function(array) {
    var s = array[0]
    for (var i = 0; i < array.length; i++) {
        var n = array[i]
        if (n > s) {
            s = n
        }
    }
    return s
}

var find = function(array, element) {
    var index = -1
    for (var i = 0; i < array.length; i++) {
        var e = array[i]
        if (e == element) {
            index = i
            break
        }
    }
    return index
}

var topStudent = function(students) {
    /*
    students 是 array
    里面的每个元素都是如下格式的 object
    {
        'name': 'gua',
        'sex': '男',
        'score': 127,
    }
    返回 score 最高的那个元素(object)

    提示：
        遍历 array，把 array 中的 score 存到一个数组 list 中，
        使用以前作业的 max 函数来得到 list 中最大元素
        使用以前作业的 find 函数得到最大元素在 list 中的下标 index
        array[list] 就是最后计算出来的结果

    分步提示：
        1. 遍历 array，每次遍历得到 object，把 object 的 score 存到一个数组 list 中，
        2. 使用以前作业的 max 函数来得到 list 中最大元素 element
        3. 使用以前作业的 find 函数得到 element 在 list 中的下标 index
        4. array[list] 就是最后计算出来的结果
    */
    var list = []
    for (var i = 0; i < students.length; i++) {
        var e = students[i]
        var score = e.score
        list.push(score)
    }
    var element = max(list)
    var index = find(list, element)
    var r = students[index]
    return r
}

// 目前只有两个数据, 自行扩充到 5 个
var student_list = [
    {
        'name': 'gua1',
        'sex': '男',
        'score': 127,
    },
    {
        'name': 'gua2',
        'sex': '男',
        'score': 99,
    },
    {
        'name': 'gua3',
        'sex': '男',
        'score': 107,
    },
    {
        'name': 'gua4',
        'sex': '男',
        'score': 104,
    },
    {
        'name': 'gua5',
        'sex': '男',
        'score': 145,
    },
]





// 作业 7
// 做不出尽早看提示或者到群里讨论或者发帖
//
var formatedWeekday = function(day) {
    /*
    day 是代表星期的数字, 从周一到周日分别是 1 2 3 4 5 6 7
    返回 '星期一' '星期二' 这样的描述字符串

    提示：
        使用两个数组 numbers 和 weekdays 分别存储 1 2 3 4 5 6 7 和 '星期一' '星期二' 到 '星期日' 这些元素
        得到 day 在 numbers 中的下标，weekdays[index] 就是需要的结果

    分步提示：
        1. 使用数组 numbers 存储 1 2 3 4 5 6 7 这些元素
        2. 使用数组 weekdays 存储 '星期一' '星期二' 到 '星期日' 这些元素
        3. 使用以前作业的 find 函数得到 day 在 numbers 里的下标 index
        4. weekdays[index] 就是需要的结果，返回这个值
    */
    var numbers = [1, 2, 3, 4, 5, 6, 7]
    var weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
    var index = find(numbers, day)
    var weekday = weekdays[index]
    return weekday
}

var testFormattedWeekday = function() {
    ensure(formatedWeekday(3) == '星期三', 'test formatted weekday 1')
    ensure(formatedWeekday(1) == '星期一', 'test formatted weekday 2')
    ensure(formatedWeekday(7) == '星期日', 'test formatted weekday 3')
}


// 作业 8
// 做不出尽早看提示或者到群里讨论或者发帖
//
var discount = function(price, grade) {
    /*
    price 是一个 int
    grade 合法情况下一共 6 种取值, 还可能没有给出这个参数
        '小学生'
        '初中生'
        '高中生'
        '大学生'
        '研究生'
    对应的折扣分别是 5 6 7 8 9

    注意, 如果调用者没有给出 grade 参数, 没有折扣

    返回折扣后的价格

    提示：
        这道题目和作业 7 类似，分别使用两个数组来储存 grade 和 price 这些数组信息
        然后计算下标，得到最后的折扣

    分步提示：
        1. 使用数组 grades 存储 '小学生' '初中生' '高中生' '大学生' '研究生' 这些信息
        2. 使用数组 prices 存储 5 6 7 8 9 这些信息
        3. 使用以前作业的 find 函数得到 grade 在数组 grades 中的下标 index
        4. 如果 index 为 -1， 返回 price
        4. 如果 index 不为 -1，计算 price * prices[index] / 10 的结果，并且返回这个结果
    */
    // 不要像下面这样写代码
    // if (grade == '小学生') {
    //     return price * 0.5
    // } else if (grade == '初中生') {
    //     return price * 0.6
    // } else if (grade == '高中生') {
    //     return price * 0.7
    // } else if (grade == '大学生') {
    //     return price * 0.8
    // } else if (grade == '研究生') {
    //     return price * 0.9
    // } else {
    //     return price
    // }
    // 有些人会告诉你用 switch case 这样的方式来优化, 实际上那种方式更加糟糕

    // 这种使用字典(object)解决很多个 if else if 的问题的方法叫做表驱动法
    var d = {
        '小学生': 0.5,
        '初中生': 0.6,
        '高中生': 0.7,
        '大学生': 0.8,
        '研究生': 0.9,
    }
    var dis = d[grade]
    // 假如 grade 是 小学生
    // 那就相当于 d.小学生
    // 如果一个参数没有传过来, 那这个参数的值就是 undefined
    if (grade == undefined) {
        dis = 1
    }
    price = price * dis
    return price
}

var testDiscount = function() {
    var price = 100

    ensure(discount(price, '小学生') == 50, 'discount error 1')
    ensure(discount(price, '大学生') == 80, 'discount error 2')
    ensure(discount(price) == 100, 'discount error 3')
}

// 作业 9
// 做不出尽早看提示或者到群里讨论或者发帖
var nChar = function(char, n) {
    var s = ''
    for (var i = 0; i < n; i++) {
        s += char
    }
    return s
}

var ljust = function(s, width, fillchar=' ') {
    /*
    s 是 string
    width 是 int
    fillchar 是 长度为 1 的字符串, 默认为空格 ' '

    如果 s 长度小于 width, 则在末尾用 fillchar 填充并返回
    否则, 原样返回, 不做额外处理

    返回 string 类型
    */
    var len = width - s.length
    return s + nChar(fillchar, len)
}
var prettyLog = function(array) {
    /*
    array 是 array 类型, 里面的元素都是字符串

    按如下的格式返回这个 array
    假设 array 是 ['python', 'js', 'objective-c']
    那么返回的数据是一个数组, 多了首尾两个元素
    [
        '+++++++++++++++',
        '+ python      +',
        '+ js          +',
        '+ objective-c +',
        '+++++++++++++++',
    ]
    返回包含了 string 的 array

    提示：
        先计算出数组中最长的那个字符串的长度
        然后计算出每行的长度

    分步提示：
        1. 定义一个数组 result 来存储最后返回的结果，初始值为 []
        2. 使用以前作业中的 max 函数得到 array 中最长的字符串的长度 len
        3. 观察发现，返回的元素中首尾两个元素的长度都为 len + 4
            使用以前作业的 zfill 函数得到 len + 4 个 '+', 结果为 first，
            把 first 添加到数组中
        4. 遍历数组 array，对于每次遍历的元素 s
            都使用以前作业的 center 函数得到需要填充的元素 element，
            在 element 首尾补上 '+'，
            并且依次添加到数组 result 中
        5. 因为最后一个元素和第一个元素是一样的，所以把 first 再次添加到数组 result 中
        6. 最后 result 就是需要的结果，返回 result
    */
    var result = []

    // 把 array 中元素的长度存到数组中
    var lengths = []
    for (var i = 0; i < array.length; i++) {
        var a = array[i]
        lengths.push(a.length)
    }
    // 得到最大的长度
    var len = max(lengths)
    // 生成第一个元素，push 到数组中
    var char = '+'
    var first = nChar(char, len + 4)
    result.push(first)

    // push 中间三个元素
    for (var i = 0; i < array.length; i++) {
        var s = array[i]
        var element = ljust(s, len)
        var e = '+ ' + element + ' +'
        result.push(e)
    }

    // 最后再 push 末尾的元素
    result.push(first)
    return result
}

var testPrettyLog = function() {
    var array = ['python', 'js', 'objective-c']
    var prettyArray = [
        '+++++++++++++++',
        '+ python      +',
        '+ js          +',
        '+ objective-c +',
        '+++++++++++++++',
    ]

    var test = arrayEquals(prettyLog(array), prettyArray)
    ensure(test, 'test pretty log')
}


var __main = function() {
    // testStartsWith()
    // testFindIn()
    // testFindAllIn()
    // testFindAllString()
    // testEndsWith()

    // var top = topStudent(student_list)
    // log('top student', top)

    // testFormattedWeekday()
    // testDiscount()
    testPrettyLog()
}

__main()
