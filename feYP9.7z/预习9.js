/*
第 9 课的上课内容

主要是 mouseover 和 mouseout 事件
还有常见的几个套路
*/
