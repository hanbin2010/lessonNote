// 今天上课的主要内容有

/*
使用下面的功能实现博客程序
node
express
ajax


文件分布如下
app_blog.js             后端程序主文件
blog.js                 处理 blog 数据存储的文件
blog.json               存储 blog 数据的文件（相当于数据库）
blog_index.html         博客主页的 html 文件
blog_detail.html        博客详情页面 html 文件


运行程序方式如下
1. 切换到项目目录下 yarn install
2. 运行 node app_blog.js


这只是初步的程序，上课会增加所有必须的功能
*/
