// nodejs 安装(群里会上传安装包, 不用去额外下载)
//

// npm(node package manager)
// package(包) 就是我们之前说的库
// 应该使用 yarn, 上课会讲

var log = console.log.bind(console)


// 下面是一个 node 程序, 具体使用方法, 上课会讲
var a = 'hello'
console.log(a, ' gua')

// require 函数来引入一个模块
// fs 是文件读写模块, 这是 node 的标准库
var fs = require('fs')
// 第一个参数是路径, '.' 表示当前目录
// 第二个参数是回调函数, 在读取完成之后会被调用
// fs.readdir('.', function(err, files) {
//     console.log(typeof err, err)
//     if (err != null) {
//         console.log(err)
//     } else {
//         console.log('files', files)
//     }
// })

// 删除一个文件
var file = 'message.txt'
// fs.unlink(file, (err) => {
//     // 大家普遍喜欢用这样的方式来判断 err 是否为空
//     // 实际上不好, 应该写全 if (err != null)
//     if (err != null) {
//         log('error', err, err.path)
//     } else {
//         console.log(`${file} 成功删除`)
//     }
// })

// 写入文件
// var text = '你好 Node.js'
// log('写入前')
// fs.writeFile(file, text, (error) => {
//     if (error != null) {
//         // 这是常见的 js 处理错误的方法, throw 会中断程序
//         // 你不用这样写程序, 但是你要看明白这是什么意思
//         throw error
//     } else {
//         log('写入成功')
//     }
// })
// log('写入文件后')

/*
* 异步编程的概念
* */
// 1. 我们先写入文件
// 2. 写入成功后, 读取当前目录看看是否有这个文件
// 3. 如果有这个文件, 我们读取文件的内容并且 log 出来
// 4. 然后我们删除这个文件
var filename = 'message.txt'
var text = '你好 Node.js'
// fs.writeFile(file, text, (error) => {
//     if (error != null) {
//         // 这是常见的 js 处理错误的方法, throw 会中断程序
//         // 你不用这样写程序, 但是你要看明白这是什么意思
//         throw error
//     } else {
//         fs.readdir('.', (err, files) => {
//             if (err != null) {
//                 log('error', err)
//             } else {
//                 if (files.includes(filename)) {
//                     fs.readFile(filename, (error, data) => {
//                         // data 并不是 string, 而是一个 Buffer 对象(以后会讲)
//                         log('读取成功', data)
//                         fs.unlink(filename, (err) => {
//                             if (err != null) {
//                                 log('删除文件错误 error', err)
//                             } else {
//                                 log(`最后一步, ${filename} 成功删除`)
//                             }
//                         })
//                     })
//                 }
//             }
//         })
//     }
// })


var guasync = function(asyncall) {
    setTimeout(function() {
        asyncall()
    }, 0)
}


guasync(function() {
    fs.writeFileSync(filename, text)
    var files = fs.readdirSync('.')
    if (files.includes(filename)) {
        var data = fs.readFileSync(filename)
        // 可以用 toString 方法把 buffer 对象转成字符串
        var s = data.toString()
        log('guasync data', s)
        fs.unlinkSync(filename)
        log('删除文件', filename)
    }
    log('guasync 结束')
})

console.log('async')