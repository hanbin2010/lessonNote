var log = console.log.bind(console)

// ======
// 测试
// ======
//
// 定义我们用于测试的函数
// ensure 接受两个参数
// condition 是 bool, 如果为 false, 则输出 message
// 否则, 不做任何处理
var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if (!condition) {
        log('*** 测试失败 {', message)
    } else {
        log('+++ 测试成功')
    }
}

var arrayEquals = function(a, b) {
    if (a.length != b.length) {
        return false
    }
    for (var i = 0; i < a.length; i++) {
        var a1 = a[i]
        var b1 = b[i]
        if (a1 != b1) {
            return false
        }
    }
    return true
}


// 作业 1
//

var ensureArrayEquals = function(a, b, message) {
    var condition = arrayEquals(a, b)
    ensure(condition, message)
}

var unique = function(a) {
    /*
    a 是一个 array
    返回一个 array, 包含了 a 中所有元素, 但不包含重复元素
    例如 a 是 [1, 2, 3, 1, 3, 5]
    返回 [1, 2, 3, 5]
    */


    /*  这是提示
    1, 创建新数组 r 来保存数据
    2, 遍历 a，对于每个在 a 中的元素 n，检测 r 中是否已经包含了 n
    3, 如果不包含，就把 n 添加到 r 中
    4, 循环结束后，返回 r
    */
    var r = []
    for (var i = 0; i < a.length; i++) {
        var n = a[i]
        if (!r.includes(n)) {
            r.push(n)
        }
    }
    return r
}

// 注意, 要自行实现 ensureArrayEquals 来判断两个数组是否相等
//
// ensureArrayEquals(unique([1, 2, 3, 1, 3, 5]), [1, 2, 3, 5], 'test 1')
// ensureArrayEquals(unique([1, 1, 3, 3, 1, 3]), [1, 3], 'test 2')
var testUnique = function() {
    var u1 = unique([1, 2, 3, 1, 3, 5])
    var u2 = unique([1, 1, 3, 3, 1, 3])

    ensureArrayEquals(u1, [1, 2, 3, 5], 'unique test 1')
    ensureArrayEquals(u2, [1, 3], 'unique test 1')
}


// 作业 2
//
var intersection = function(a, b) {
    /*
    a b 都是 array

    返回一个 array, 里面的元素是同时出现在 a b 中的元素
    也就是取交集
    这个 array 中不包含重复元素
    */


    /*  这是提示
    1, 创建一个新数组r
    2, 遍历 a
    3, 对于 a 中的每个元素, 判断是否在 b 中出现
    4, 如果出现就 push 到新数组r
    5, 循环结束后，使用 unique 来去重
    */
    var r = []
    for (var i = 0; i < a.length; i++) {
        var n = a[i]
        if (b.includes(n)) {
            r.push(n)
        }
    }
    return r
}

var testIntersection = function() {
    var a = [1, 2, 3, 4]
    var b = [2, 3, 4, 5]
    var c = [1, 4, 6, 8]
    var i1 = intersection(a, b)
    var i2 = intersection(a, c)
    var i3 = intersection(b, c)

    ensureArrayEquals(i1, [2, 3, 4], 'intersection test 1')
    ensureArrayEquals(i2, [1, 4], 'intersection test 2')
    ensureArrayEquals(i3, [4], 'intersection test 3')
}


// 作业 3
//
var union = function(a, b) {
    /*
    a b 都是 array

    返回一个 array, 里面的元素是所有出现在 a b 中的元素
    这个 array 中不包含重复元素

    [提示]: 最简单的方法是把两个数组合并为一个数组后调用 unique
    */
    var l = a.slice(0)
    for (var i = 0; i < b.length; i++) {
        var n = b[i]
        l.push(n)
    }
    return unique(l)
}

var testUnion = function() {
    var a = [1, 2, 3, 4]
    var b = [2, 3, 4, 5]
    var c = [1, 4, 6, 8]

    var u1 = union(a, b)
    var u2 = union(a, c)
    var u3 = union(b, c)

    ensureArrayEquals(u1, [1, 2, 3, 4, 5], 'union test 1')
    ensureArrayEquals(u2, [1, 2, 3, 4, 6, 8], 'union test 2')
    ensureArrayEquals(u3, [2, 3, 4, 5, 1, 6, 8], 'union test 3')
}


// 作业 4
//
var difference = function(a, b) {
    /*
    a b 都是 array

    返回一个 array, 里面的元素是
    所有在 a 中有 b 中没有的元素
    这个 array 中不包含重复元素


    [提示]: 和之前几题相似的套路

    */
    var l = []
    for (var i = 0; i < a.length; i++) {
        var n = a[i]
        if (!b.includes(n)) {
            l.push(n)
        }
    }

    return l
}

var testDifference = function() {
    var a = [1, 2, 3, 4]
    var b = [2, 3, 4, 5]
    var c = [1, 4, 6, 8]

    var d1 = difference(a, b)
    var d2 = difference(a, c)
    var d3 = difference(b, c)

    ensureArrayEquals(d1, [1], 'difference test 1')
    ensureArrayEquals(d2, [2, 3], 'difference test 2')
    ensureArrayEquals(d3, [2, 3, 5], 'difference test 3')
}


// 作业 5
//
var differenceAll = function(a, b) {
    /*
    a b 都是 array

    返回一个 array, 里面的元素是
    所有在 a b 中的非公共元素
    这个 array 中不包含重复元素


    [提示]: 对 a b 分别 difference 并 push 结果到新数组
    */
    var a1 = difference(a, b)
    var a2 = difference(b, a)
    return union(a1, a2)
}

var testDifferenceAll = function() {
    var a = [1, 2, 3, 4]
    var b = [2, 3, 4, 5]
    var c = [1, 4, 6, 8]

    var d1 = differenceAll(a, b)
    var d2 = differenceAll(a, c)
    var d3 = differenceAll(b, c)

    ensureArrayEquals(d1, [1, 5], 'difference all test 1')
    ensureArrayEquals(d2, [2, 3, 6, 8], 'difference all test 2')
    ensureArrayEquals(d3, [2, 3, 5, 1, 6, 8], 'difference all test 3')
}


// 作业 6
//
var isSubset = function(a, b) {
    /*/
    a b 都是 array

    检查是否 a 中的每个元素都在 b 中出现
    返回 bool


    [提示]: 循环遍历 a 中的元素判断是否在 b 中存在，只要不存在就失败

    /*/
    for (var i = 0; i < a.length; i++) {
        var n = a[i]
        if (!b.includes(n)) {
            return false
        }
    }
    return true
}

var testIsSubset = function() {
    var test1 = isSubset([1, 2, 3], [1, 2, 3, 4])
    var test2 = isSubset([1, 2], [2, 3, 4])

    ensure(test1, 'test is subset 1')
    ensure(!test2, 'test is subset 2')
}


// 作业 7
//
var appendHtml = function(element, html) {
    /*
    element 是一个标签
    html 是一段 html 字符串
    把 html 作为子元素插入到 element 的末尾
    上课一直在用这个函数

    用法如下:
    var b = document.querySelector('body')
    appendHtml(b, '<h1>hello</h1>')
    */
    element.insertadjacenthtml('beforeend', html)
}

// 作业 8
//
var bindEvent = function(element, eventName, callback) {
    /*
    element 是一个标签
    eventName 是一个 string, 表示事件的名字
    callback 是一个函数
    用法如下, 假设 button 是一个标签
    bindEvent(button, 'click', function(){
        log('click 事件')
    })
    */
    element.addEventListener(eventName, callback)
}

// 作业 9
//
var bindEventDelegate = function(element, eventName, callback, responseClass) {
    /*
    element 是一个标签
    eventName 是一个 string, 表示事件的名字
    callback 是一个函数
    responseClass 是一个字符串

    在 element 上绑定一个事件委托
    只会响应拥有 responseClass 类的元素
    */
    element.addEventListener(eventName, function(event) {
        var self = event.target
        if (self.classList.contains(responseClass)) {
            callback(event)
        }
    })
}

// 作业 10
//
var append = function(selector, html) {
    /*
    selector 是一个 string, 选择器, 有如下三种取值
        1, 标签选择器, 如 'div'
        2, class 选择器, 如 '.red'
        3, id 选择器, 如 '#id-input-name'
    html 是一段 html 字符串
    把 html 作为子元素插入到 selector 选中的所有元素的末尾
    */
    var elements = document.querySelectorAll(selector)
    for (var i = 0; i < elements.length; i++) {
        var e = elements[i]
        e.insertadjacenthtml('beforeend', html)
    }
}

// 作业 11
// 这是本课 最后一个作业
var bindAll = function(selector, eventName, callback, responseClass) {
    /*
    selector 是一个 string, 选择器, 有如下三种取值
        1, 标签选择器, 如 'div'
        2, class 选择器, 如 '.red'
        3, id 选择器, 如 '#id-input-name'
    eventName 是一个 string, 表示事件的名字
    callback 是一个函数
    responseClass 是一个字符串, 这个参数可以为空

    给 selector 选中的所有元素绑定 eventName 事件
    当 responseClass 给出的时候, callback 只会响应拥有 responseClass 类的元素
    当 responseClass 没有给的时候, callback 直接响应

    注意, 这题做不出来就放弃
    */
    var elements = document.querySelectorAll(selector)
    for (var i = 0; i < elements.length; i++) {
        var e = elements[i]
        if (responseClass == undefined) {
            bindEvent(e, eventName, function(event) {
                callback(event)
            })
        } else {
            bindEvent(e, eventName, function(event) {
                var self = event.target
                if (target.classList.contains(responseClass)) {
                    callback(event)
                }
            })
        }
    }
}

var __main = function() {
    // testUnique()
    // testIntersection()
    // testUnion()
    // testDifference()
    // testDifferenceAll()
    testIsSubset()
}

__main()
