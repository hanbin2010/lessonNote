var log = console.log.bind(console)

var e = function(selector) {
    var element = document.querySelector(selector)
    return element
}

// es 返回一个数组，包含所有被选中的元素
var es = function(selector) {
    var elements = document.querySelectorAll(selector)
    return elements
}

// bindAll 给所有的元素绑定事件
var bindAll = function(elements, eventName, callback) {
    for (var i = 0; i < elements.length; i++) {
        var tag = elements[i]
        tag.addEventListener(eventName, callback)
    }
}
