// 注意, 作业中提到的国旗的颜色我们只画线框不填色
// 所有国旗的矩形长宽分别为 400 * 300(包括瑞士国旗)
// 作业 1
// 实现一个圆形函数
// x y 是圆形的圆心
// r 是半径
// circle(x, y, r)
var polygon = function(x, y, n, l) {
    var i = 0
    //
    // var jcdu = 180 - (180 * (n - 2) / n)
    // 这个式子可以化简为下面的式子
    var jcdu = 360 / n
    while (i < n) {
        forward(l)
        right(jcdu)
        i = i + 1
    }
}

var circle = function(x, y, r) {
    jump(x, y)
    setHeading(0)

    var n = 36
    var l = (2 * Math.PI * r) / n
    var jcdu = (90 + (360 / n) / 2)

    left(jcdu)
    penup()
    forward(r)
    pendown()
    right(jcdu)

    polygon(x, y, n, l)
}

// circle(0, 0, 50)


// 作业 2
// 实现一个矩形函数
// x y 是矩形中心的坐标
// w h 是宽高
// center_rect(x, y, w, h)
var rect = function(x, y, w, h) {
    jump(x, y)
    setHeading(0)

    var i = 0
    while (i < 2) {
        forward(w)
        right(90)
        forward(h)
        right(90)
        i = i + 1
    }
}

var center_rect = function(x, y, w, h) {
    var x1 = x - w / 2
    var y1 = y - h / 2
    rect(x1, y1, w, h)
}

// center_rect(0, 0, 100, 50)


// 作业 3
// 实现一个正五角星(国旗大星星那种)函数
// x y 是五角星顶部横边的左边点坐标
// length 是一条线的长度
// 这是一个正五角星
// vgwujcxy(x, y, length)
var vgwujcxy = function(x, y, length) {
    jump(x, y)
    setHeading(0)

    var i = 0
    while (i < 5) {
        forward(length)
        right(144)
        i = i + 1
    }
}

// vgwujcxy(-100, 50, 50)


// 作业 4
// 实现一个函数画日本国旗
// 调用 2 个函数画日本国旗
// 一个画背景的白色矩形
// 一个画中间的红色圆
// japan()

var japan = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0
    // 画矩形
    center_rect(x, y, w, h)
    // 画圆形
    var r = 0.35 * h
    circle(x, y, r)
}
japan()


// 作业 5
// 实现一个五角星函数
// x y 是五角星的中心点坐标
// r 是五角星外接圆的半径
// wujcxy(x, y, r)
// 为了实现这个函数, 你需要使用三角函数计算顶点在圆上的坐标
// 如果你不懂这个数学计算过程, 应该在群里提问
// 我帮你实现了正弦余弦函数如下
var sin = function(degree) {
    // 如上课所述, 数学库里面的 sin 函数接受弧度作为参数
    // 我们这个函数接受角度, 下面是弧度转角度的公式
    var radians = degree * Math.PI / 180
    return Math.sin(radians)
}

var cos = function(degree) {
    var radians = degree * Math.PI / 180
    return Math.cos(radians)
}

var wujcxy = function(x, y, r) {
    var du = 18
    // 五角星顶部横边的左边点的坐标
    var x1 = x - cos(du) * r
    var y1 = y - sin(du) * r
    // 五角星的长度为
    var length = cos(du) * r * 2
    vgwujcxy(x1, y1, length)
}

// wujcxy(0, 0, 105)


// 作业 6
// 实现一个函数画中国国旗(以下国旗题目都是如此 不重复了)
// 调用 2 个函数画中国国旗
// 一个画红色背景
// 另一个画五角星（函数里调用 5 次，不要求角度朝向，不要求尺寸, 只要 5 个五角星即可）
// 当然你也可以使用第 5 题 wujcxy 这个函数画出比较完美的国旗 (不过这不是学习的重点)
// china()
var china = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    // 画矩形
    center_rect(x, y, w, h)

    // 画五角星
    vgwujcxy(-180, -100, 100)
    vgwujcxy(-60, -120, 20)
    vgwujcxy(-60, -80, 20)
    vgwujcxy(-60, -40, 20)
    vgwujcxy(-60, 0, 20)
}


// 作业 7
// 实现一个函数画法国国旗
// france()
var france = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    w = w / 3

    x = -200
    y = -150
    var x1 = x
    var x2 = x1 + w
    var x3 = x2 + w

    // 画三个纵向矩形
    rect(x1, y, w, h)
    rect(x2, y, w, h)
    rect(x3, y, w, h)
}
// france()


// 作业 8
// 画德国国旗
// germany()
var germany = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    h = h / 3

    x = -200
    y = -150
    var y1 = y
    var y2 = y1 + h
    var y3 = y2 + h

    // 画三个横向矩形
    rect(x, y1, w, h)
    rect(x, y2, w, h)
    rect(x, y3, w, h)
}
germany()


// 作业 9
// 画 冈比亚国旗
// gambia()
var gambia = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    h = h / 3
    var h1 = h
    var h2 = 1 / 8 * h
    var h3 = 6 / 8 * h
    var h4 = h2
    var h5 = h

    x = -200
    y = -150

    var x1 = 0
    var x2 = 0
    var x3 = 0
    var x4 = 0
    var x5 = 0

    var y1 = 0 - h
    var y2 = 0 - (h2 + h3) / 2
    var y3 = 0
    var y4 = (h3 + h4) / 2
    var y5 = 0 + h

    // 画五个横向矩形
    center_rect(x1, y1, w, h1)
    center_rect(x2, y2, w, h2)
    center_rect(x3, y3, w, h3)
    center_rect(x4, y4, w, h4)
    center_rect(x5, y5, w, h5)
}

// 作业 10
// 画 瑞士国旗
// switzerland()
var switzerland = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    var width = 150
    var height = 50

    center_rect(x, y, w, h)
    center_rect(x, y, width, height)
    center_rect(x, y, height, width)
}
switzerland()


//
// 作业 11
// 画朝鲜国旗
//



var northkorea = function() {
    var w = 400
    var h = 300
    var x = 0
    var y = 0

    var h1 = 4 / 25 * h
    var h2 = 1 / 25 * h
    var h3 = 15 / 25 * h
    var h4 = h2
    var h5 = h1

    var x1 = -200
    var x2 = -200
    var x3 = -200
    var x4 = -200
    var x5 = -200

    var y1 = -150
    var y2 = y1 + h1
    var y3 = y2 + h2
    var y4 = y3 + h3
    var y5 = y4 + h4

    rect(x1, y1, w, h1)
    rect(x2, y2, w, h2)
    rect(x3, y3, w, h3)
    rect(x4, y4, w, h4)
    rect(x5, y5, w, h5)

    var r = h3 * (2 / 3) * (1 / 2)
    x = -200 + w * 3 / 8
    y = 0

    circle(x, y, r)
    wujcxy(x, y, r)
}

// northkorea()
