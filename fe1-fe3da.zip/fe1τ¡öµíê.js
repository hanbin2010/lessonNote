// 例子 1
//
// 实现函数, 用于画一个边长 100 的正方形
// 参数 x, y 是正方形左上角坐标
var square = function(x, y) {
    jump(x, y)
    // 设置朝向, 确保箭头朝向 右边
    // 当然如果是用 goto 来画的话, 就不用关心朝向
    setHeading(0)
    // 循环画正方形
    // 当然, 你可以用 goto 来画
    // 只需要计算一下四个顶点的坐标 (这很简单)
    var i = 0
    while (i < 4) {
        forward(100)
        right(90)
        i = i + 1
    }
}

// 1
// 实现函数, 用于画一个正方形, 边长由参数提供
// 参数 x, y 是正方形左上角坐标
// 参数 l(注意，这里是字母 l，不是数字 1) 是正方行边长
// 函数声明如下
// square(x, y, l)

// 按 Ctrl + / 可以批量注释
// 提示:
// 本题需要根据例子 1 的代码修改
//
// 分步提示:
// 1. 在例子 1 的基础上再增加一个参数 l （这个是字母 l，不是数字 1）
// 2. forward 的参数换成 l

var square = function(x, y, l) {
    jump(x, y)
    // 设置朝向, 确保箭头朝向 右边
    // 当然如果是用 goto 来画的话, 就不用关心朝向
    setHeading(0)
    // 循环画正方形
    // 当然, 你可以用 goto 来画
    // 只需要计算一下四个顶点的坐标 (这很简单)
    var i = 0
    while (i < 4) {
        forward(l)
        right(90)
        i = i + 1
    }
}

// square(0, 0, 100)
// square(-100, -50, 75)


// 2
// 实现函数, 用于画一个矩形, 长宽由参数提供
// 参数 x, y 是左上角坐标
// 参数 w, h 是长宽
// 函数声明如下
// rect(x, y, w, h)

// 提示:
// 根据例子 1 的程序修改
//
// 分步提示:
// 1. 考虑矩形只重复两次(一次会画出长和宽), 所以只需要循环 2 次
// 2. 每次循环做几个操作
//     i 递增 1
//     往前移动 w
//     右转 90 度
//     往前移动 h
//     右转 90 度
var rect = function(x, y, w, h) {
    jump(x, y)
    // 设置朝向, 确保箭头朝向 右边
    // 当然如果是用 goto 来画的话, 就不用关心朝向
    setHeading(0)
    // 循环画正方形
    // 当然, 你可以用 goto 来画
    // 只需要计算一下四个顶点的坐标 (这很简单)
    var i = 0
    while (i < 2) {
        forward(w)
        right(90)
        forward(h)
        right(90)
        i = i + 1
    }
}



// 3
// 画一排正方形, 一共 5 个
// 从 0 0 点开始, 边长为 30, 正方形之间间隔为 0
// 函数声明如下
// square5()

// 提示:
// 根据资料中的循环例子, 计算每个正方形的坐标
//
// 分步提示:
// 1. 要画出 5 个正方形, 表明循环 5 次
// 2. 计算每次循环的正方形左上角坐标 x, y
// 3. 在每次循环中画正方形, 调用作业 1 中实现的函数
var square5 = function() {
    var n = 5
    var bmih = 30
    // 0 30 60 90 120
    // 对应的 i 分别是
    // 0 1 2 3 4
    var i = 0
    while (i < n) {
        var x1 = i * bmih
        var y1 = 0
        square(x1, y1, bmih)
        i = i + 1
    }
}
// square5()



// 4
// 画一排正方形, 一共 5 个
// 从 0 0 点开始, 边长为 30, 正方形之间间隔为 10 像素
// 函数声明如下
// square5_10()

// 提示:
// 作业 4 和作业 3 的不同之处在于每个正方形的左上角坐标不同, 计算出每个左上角的坐标之后,
// 参考作业 3 的提示
var square5_10 = function() {
    var n = 5
    var bmih = 30
    var space = 10
    // 0 30 60 90 120
    // 对应的 i 分别是
    // 0 1 2 3 4
    var i = 0
    while (i < n) {
        var x1 = i * (bmih + space)
        var y1 = 0
        square(x1, y1, bmih)
        i = i + 1
    }
}

// square5_10()



// 5
// 实现函数, 画一排正方形, 有如下参数
// x, y 是第一个正方形左上角坐标
// n 是正方形的个数
// space 是两个正方形之间的间距
// len 是正方形的边长
// square_line(x, y, n, space, len)

// 提示:
// 作业 4 中画 5 个正方形, 循环 5 次
// 作业 5 中画 n 个正方形, 循环 n 次, 同时两个正方形的间距从 10 换成了 space
var square_line = function(x, y, n, space, len) {
    var bmih = len
    var i = 0
    while (i < n) {
        // 把要传递的参数提前计算好，一定要这么做
        var x1 = x + i * (bmih + space)
        var y1 = y
        square(x1, y1, bmih)
        i = i + 1
    }
}

// square_line(-100, 50, 3, 20, 30)



// 6
// 实现函数, 用上题的函数来画一个正方形方阵, 参数如下
// x, y 是第一个正方形左上角坐标
// space 是两个正方形之间的间距
// len 是正方形的边长
// n 是横向正方形的个数
// m 是纵向正方形的个数
// square_square(x, y, space, len, n, m)

// 提示:
// m 是纵向正方形的个数, 所以需要循环 m 次,
// 每次循环画一排正方形, 即作业 5 的要求, 所以每次循环调用作业 5 的 square_line 函数就行
var square_square = function(x, y, space, len, n, m) {
    var i = 0
    while (i < m) {
        // 把要传递的参数提前计算好，一定要这么做
        var x1 = x
        var y1 = y + i * (len + space)
        // x, y, n, space, len
        square_line(x1, y1, n, space, len)
        i = i + 1
    }
}

// square_square(-100, 50, 10, 50, 3, 2)



// 7
// 实现函数, 画一排矩形, 有如下参数
// x, y 是第一个矩形左上角坐标
// w, h 是矩形长宽
// n 是矩形的个数
// space 是两个矩形之间的间距
// rect_line(x, y, w, h, n, space)

// 提示:
// 作业 7 和作业 5 的区别是作业 7 要求画矩形, 作业 5 要求话正方形,
// 也就是在作业 7 的每次循环中画一个矩形, 即调用画矩形的函数
var rect_line = function(x, y, w, h, n, space) {
    var i = 0
    while (i < n) {
        // 把要传递的参数提前计算好，一定要这么做
        var x1 = x + i * (w + space)
        var y1 = y
        rect(x1, y1, w, h)
        i = i + 1
    }
}

// rect_line(-100, 50, 30, 20, 3, 10)


// 8
// 实现函数, 画一个矩形方阵, 参数如下
// x, y 是第一个矩形左上角坐标
// space 是两个矩形之间的间距(横向和纵向)
// w, h 是矩形的长宽
// n 是横向矩形的个数
// m 是纵向矩形的个数
// rect_square(x, y, space, w, h, n, m)

// 提示:
// 参考作业 6, 共 m 次循环, 在每次循环中, 画一排矩形, 也就是调用作业 7 中实现的函数


var rect_square = function(x, y, space, w, h, n, m) {
    var i = 0
    while (i < m) {
        // 把要传递的参数提前计算好，一定要这么做
        var x1 = x
        var y1 = y + i * (h + space)
        // x, y, w, h, n, space
        rect_line(x1, y1, w, h, n, space)
        i = i + 1
    }
}
// square_square(-100, 50, 10, 30, 20, 3, 2)

// 写 what 不写 how



// 9
// 实现函数, 画一个正多边形, 参数如下
// x y 是起点, 设起点为多边形的顶部边的左顶点
// n 是多边形的边数
// l 是边长
// polygon(x, y, n, l)

// 提示:
// 正多边形和正方形的区别是前者循环 n 次, 后者循环 4 次, 其他都可以直接参考作业 1
var polygon = function(x, y, n, l) {
    jump(x, y)
    setHeading(0)

    var i = 0
    //
    // var jcdu = 180 - (180 * (n - 2) / n)
    // 这个式子可以化简为下面的式子
    var jcdu = 360 / n
    while (i < n) {
        forward(l)
        right(jcdu)
        i = i + 1
    }
}

// polygon(-100, -100, 5, 30)
