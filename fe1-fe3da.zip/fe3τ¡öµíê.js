var log = console.log.bind(console)

// 例子 1
// 求数组的和
var sum = function(array) {
    // 先设置一个变量用来存数组的和
    var s = 0
    for (var i = 0; i < array.length; i++) {
        // 用变量 n 保存元素的值
        var n = array[i]
        // 累加到变量 s
        s = s + n
    }
    // 循环结束, 现在 s 里面存的是数组中所有元素的和了
    return s
}

var ensure = function(condition, message) {
    // condition 是一个布尔值
    // message 是 string，condition 不成立的时候被输出
    if (!condition) {
        console.log(message)
    } else {
        console.log('测试成功')
    }
}

var ensureEqual = function(a, b, message) {
    if (a != b) {
        console.log(`${message}, (${a}) 不等于 (${b})`)
    } else {
        console.log('测试成功')
    }
}



// 作业 1
// 参数是一个只包含数字的 array
// 求 array 的乘积
// 函数定义是
var product = function(array) {
    // 先设置一个变量用来存数组的结果
    var s = 1
    for (var i = 0; i < array.length; i++) {
        // 用变量 n 保存元素的值
        var n = array[i]
        // 累乘到变量 s
        s = s * n
    }
    // 循环结束, 现在 s 里面存的是数组中所有元素的乘积了
    return s
}

var testProduct = function() {
    var numbers = [1, 2, 3, 4]
    var value = 24
    //
    ensure(product(numbers) == value, '测试出错1')
    ensure(product([1]) == 1, '测试出错2')
    ensure(product([0, 1, 2]) == 0, '测试出错3')
}

// 作业 2
// 返回一个数的绝对值
// 函数定义是
var abs = function(n) {
    if (n < 0) {
        n = -n
    }
    return n
}

var testAbs = function() {
    ensure(abs(0) == 0, 'abs error, 0')
    ensure(abs(2) == 2, 'abs error, 2')
    ensure(abs(-3) == 3, 'abs error, -3')

    log('*** abs 测试完成')
}

// 作业 3
// 参数是一个只包含数字的 array
// 求 array 中所有数字的平均数
// 函数定义是
var floatEqual = function(a, b) {
    var delta = 0.001
    return Math.abs(a - b) < delta
}

var average = function(array) {
    var n = array.length
    var s = sum(array)
    return s / n
}

var testAverage = function() {
    ensure(average([1, 2, 3]) == 2, 'average 2')
    ensure(average([1, 2, 3, 5]) == 2.75, 'average 2.75')
    var equal = floatEqual(average([2, 3, 5]), 3.33333)
    ensure(equal, 'average 3.33')

    log('*** average 测试完成')
}

// 作业 4
// 参数是一个只包含数字的 array
// 求 array 中最小的数字
// 函数定义是
var min = function(array) {
    var s = array[0]
    for (var i = 0; i < array.length; i++) {
        var n = array[i]
        if (n < s) {
            s = n
        }
    }
    return s
}

var testMin = function() {
    ensure(min([2, 3, 1, 4]) == 1, 'min error 1')
    ensure(min([4, 5, 7, 3]) == 3, 'min error 3')
}


// 作业 5
/*
参数是一个数字 n
返回以下序列的结果
1 - 2 + 3 - 4 + 5 ... n
*/
var sum1 = function(n) {
    var s = 0
    for (var i = 1; i < n + 1; i++) {
        if (i % 2 == 0) {
            s = s - i
        } else {
            s = s + i
        }
    }
    return s
}

var testSum1 = function() {
    ensure(sum1(5) == 3, 'sum1 error 1')
    ensure(sum1(4) == -2, 'sum1 error 2')
}


// 作业 6
/*
参数是一个数字 n
返回以下序列的结果
1 + 2 - 3 + 4 - ... n
*/
var sum2 = function(n) {
    var s = 1
    for (var i = 2; i < n + 1; i++) {
        if (i % 2 == 0) {
            s = s + i
        } else {
            s = s - i
        }
    }
    return s
}

var testSum2 = function() {
    ensure(sum2(1) == 1, 'sum2 error 1')
    ensure(sum2(2) == 3, 'sum2 error 2')
    ensure(sum2(3) == 0, 'sum2 error 3')
    ensure(sum2(4) == 4, 'sum2 error 4')
}


// 作业 7
/*
实现 fac 函数
接受一个参数 n
返回 n 的阶乘, 1 * 2 * 3 * ... * n
*/
var fac = function(n) {
    var s = 1
    for (var i = 1; i < n + 1; i++) {
        s = s * i
    }
    return s
}

var testFac = function() {
    ensure(fac(1) == 1, 'fac error 1')
    ensure(fac(5) == 120, 'fac error 2')
}

/*
注意 下面几题中的参数 op 是 operator(操作符) 的缩写

作业 8
实现 apply 函数
参数如下
op 是 string 类型, 值是 '+' '-' '*' '/' 其中之一
a b 分别是 2 个数字
根据 op 对 a b 运算并返回结果(加减乘除)
*/
var apply = function(op, a, b) {
    if (op == '+') {
        return a + b
    } else if (op == '-') {
        return a - b
    } else if (op == '*') {
        return a * b
    } else if (op == '/') {
        return a / b
    }
}

var testApply = function() {
    ensureEqual(apply('+', 1, 2), 3, 'apply error 1')
}

/*
作业 9
实现 applyList 函数
op 是 '+' '-' '*' '/' 其中之一
oprands 是一个只包含数字的 list
根据 op 对 oprands 中的元素进行运算并返回结果
例如, 下面的调用返回 -4
var n = applyList('-', [3, 4, 2, 1])
log(n)
// 结果是 -4, 用第一个数字减去所有的数字
*/
var applyList = function(op, oprands) {
    var s = oprands[0]
    for (var i = 1; i < oprands.length; i++) {
        var n = oprands[i]
        s = apply(op, s, n)
    }
    return s
}

var testApplyList = function(op, oprands) {
    ensureEqual(applyList('+', [1, 2, 3, 4]), 10, 'apply list 111')
    ensureEqual(applyList('-', [1, 2, 3, 4]), -8, 'apply list 222')
    ensureEqual(applyList('*', [1, 2, 3, 4]), 24, 'apply list 333')
    ensureEqual(applyList('/', [12, 2, 3]), 2, 'apply list 444')
}


/*
作业 10
实现 applyCompare 函数
参数如下
expression 是一个 array(数组), 包含了 3 个元素
第一个元素是 op, 值是 '>' '<' '==' 其中之一
剩下两个元素分别是 2 个数字
根据 op 对数字运算并返回结果(结果是 true 或者 false)
*/
var applyCompare = function(expression) {
    var op = expression[0]
    var a = expression[1]
    var b = expression[2]

    if (op == '>') {
        return a > b
    } else if (op == '<') {
        return a < b
    } else if (op == '==') {
        return a == b
    }
}

var testApplyCompare = function() {
    ensureEqual(applyCompare(['<', 1, 2]), true, 'apply compare 1')
    ensureEqual(applyCompare(['>', 2, 1]), true, 'apply compare 2')
    ensureEqual(applyCompare(['==', 2, 2]), true, 'apply compare 3')
}

/*
注意
下面这题做不出来没关系

作业 11
实现 applyOps 函数
参数如下
expression 是一个 array
expression 中第一个元素是上面几题的 op, 剩下的元素是和 op 对应的值
根据 expression 运算并返回结果

假设 expression 为 [+ 1 3 5 7]
1 + 3 + 5 + 7 = 16
那么返回的结果为 16
*/
var applyOps = function(expression) {
    var op = expression[0]
    var compares = ['>', '==', '<']

    if (compares.includes(op)) {
        var result = applyCompare(expression)
        return result
    } else {
        var oprands = expression.slice(1)
        var result = applyList(op, oprands)
        return result
    }
}

var testApplyOps = function() {
    ensureEqual(applyOps(['<', 1, 2]), true, 'apply ops 1')
    ensureEqual(applyOps(['+', 1, 2, 3, 4]), 10, 'apply ops 2')
}


// 作业 12
// 根据本周天气，绘制柱状图
// 中国本周的每日平均气温, 从周一到周日
var forecast = function(temps) {
    // 柱壮图里每个图宽 30，间距为 0
    jump(0, 0)
    setHeading(0)

    var width = 30
    for (var i = 0; i < temps.length; i++) {
        var t = temps[i]
        var x = width * i
        var y = -t
        var h = t
        var w = width
        rect(x, y, w, h)
    }
}

var testForecast = function() {
    var temps = [22, 19, 22, 21, 25, 27, 30, 28]
    forecast(temps)
}


var __main = function() {
    // 在 __main 函数里面调用我们的函数
    // testAbs()
    // testAverage()
    // testApply()
    // testApplyList()
    // testSum1()
    // testSum2()
    // testFac()
    // testApply()
    // testApplyList()
    // testApplyCompare()
    // testApplyOps()
}

__main()
