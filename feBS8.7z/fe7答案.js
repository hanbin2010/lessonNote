var log = console.log.bind(console)

var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if (condition) {
        log('*** 测试成功')
    } else {
        log('--- 测试失败', message)
    }
}

var join = function(delimiter, array) {
    /*
    delimiter 是 string
    array 是包含 string 的 array

    把 array 中的元素用 delimiter 连接成一个字符串并返回
    具体请看测试

    提示：
        在循环里面拼接 delimiter

    分步提示：
        1. 把 array 中的第一个元素赋值给 s
        2. 从 1 开始遍历数组 array，每次遍历的时候把 delimiter 和 遍历的元素 e 看成一个整体 (delimiter + e)
        3. 每次遍历的时候把这个整体累加到 s
        4. 循环结束的时候 s 就是拼接好的字符，返回这个结果 s
    */
    var s = array[0]
    for (var i = 1; i < array.length; i++) {
        // 从下标为 1 的元素开始, 把数组中每个元素拿出来
        // 加上分隔符之后再累加到 s 上
        var e = array[i]
        s += (delimiter + e)
    }
    return s
}

var testJoin = function() {
    ensure(join('#', ['hello', 'gua']) == 'hello#gua', 'join 测试 1')
    ensure(join(' ', ['hello', 'gua']) == 'hello gua', 'join 测试 2')
    ensure(join('\n', ['multi', 'line', 'string']) == 'multi\nline\nstring', 'join 测试 3')
}

// 作业 2
// 实现函数
var arrayEquals = function(a, b) {
    if (a.length != b.length) {
        return false
    }

    for (var i = 0; i < a.length; i++) {
        var a1 = a[i]
        var b1 = b[i]
        if (a1 != b1) {
            return false
        }
    }
    return true
}

var split = function(s, delimiter=' ') {
    /*
    s 是 string
    delimiter 是 string, 默认为空格 ' '

    以 delimiter 为分隔符号, 返回一个 array
    例如
    split('1 2 3', ' ') 返回 ['1', '2', '3']
    split('a=b&c=d', '&') 返回 ['a=b', 'c=d']
    注意, 测试 array 是否相等得自己写一个函数用循环来跑

    01234567
    a=bc=def
    a bc def

    提示：
        用循环找到 delimiter，记录两个变量 start 和 end 来 slice 出子字符串，把子字符串添加到数组中

    分步提示：
        1. 定义一个数组 l 来存储结果，初始值为 []
        2. 计算出 delimiter 的长度 space，因为 delimiter 的长度不一定为 1
        3. 使用 start 来记录每次 slice 的初始位置，初始值为 0
        4. 遍历字符串，slice 子字符串 slice(i, i + space)，
            如果子字符串与 delimiter 相等，把数据存储到数组 l 中。
            数组的计算方式是 s.slice(start, i)
        5. 改变 start 的值，把 i + space 设置为新的 start 下标
        6. 循环结束后，还要把最后一个元素添加到数组 l 中，这个元素为 s.slice(start)
        7. 最后数组 l 就是需要的结果，返回 l
        8. 注意，判断数组相等使用以前作业里的 arrayEquals
    */
    // r 是存储结果的数组
    var r = []
    // space 是分隔符的长度, 因为分隔符的长度是不知道的
    var space = delimiter.length
    // 用一个变量 start 来存储每次切片的开始下标
    var start = 0
    for (var i = 0; i < s.length; i++) {
        // 每次 slice delimiter 那么长的字符串
        var s1 = s.slice(i, i + space)
        // 如果切出来的这个字符串与分隔符相等
        if (delimiter == s1) {
            // 找到了一个分隔符, 就把这个分隔符前面的字符串放进数组
            var s2 = s.slice(start, i)
            r.push(s2)
            // 重新设置下次切片的开始下标
            start = i + space
        }
    }
    // 循环结束后, 把最后一个元素放进去
    // 最后一次直接从 start 切到末尾就可以
    var end = s.slice(start)
    r.push(end)
    return r
}

var testSplit = function() {
    var test1 = split('1 2 3', ' ')
    var test2 = split('a=b&c=d', '&')

    ensure(arrayEquals(test1, ['1', '2', '3']), 'split test 1')
    ensure(arrayEquals(test2, ['a=b', 'c=d']), 'split test 2')
}

// 作业 3
// 实现函数
var replaceAll = function(s, old, newString) {
    /*
    s old newString 都是 string
    返回一个「将 s 中出现的所有 old 字符串替换为 new 字符串」的字符串

    提示
        先按照 old 来 split 出一个数组，然后用 newString 来 join 这个数组

    分步提示：
        1. 调用作业 2 的 split 函数，按照 old 来 split，结果为 l
        2. 调用作业 1 的 join 函数，delimiter 为 newString，array 为第一步的 l，结果为 result
        3. 返回第二步的计算结果 result
    */
    // 先把字符串按照 old split 成一个数组
    var s1 = split(s, old)
    // 再把数组按照 newString 来 join
    var s2 = join(newString, s1)
    return s2
}

var testReplaceAll = function() {
    ensure(replaceAll('1 2 3', ' ', '#') == '1#2#3', 'replace all test 1')
    ensure(replaceAll('1&2&3', '&', ' ') == '1 2 3', 'replace all test 2')
    ensure(replaceAll('hello#gua', '#', ' ') == 'hello gua', 'replace all test 3')
}

// 作业 4
// 实现函数
var str1 = function(n) {
    /*
    n 是 int
    返回这样规律的字符串, 特殊情况不考虑
    n       返回值
    1       '1'
    2       '121'
    3       '12321'

    提示：
        把返回值分成两部分，用两个循环分别来生成这两部分

    分步提示：
        1. 定义字符串 s 来存储计算的结果，初始值为 ''
        2. 生成 12345...n 这部分内容
            循环从 0 到 n，把每次循环的元素转成字符串，并且累加到 s 上
        3. 生成 n...4321 这部分内容
            循环从 n-1 到 0，把每次循环的元素转成字符串，并且累加到 s 上
        4. 循环结束后 s 就是计算的结果，返回 s
    */
    var s = ''
    // 先左边
    for (var i = 0; i < n; i++) {
        s += String(i + 1)
    }
    // 再右边
    for (var i = n - 1; i > 0; i--) {
        s += String(i)
    }
    return s
}

var testStr1 = function() {
    ensure(str1(3) == '12321', 'str1 test 1')
    ensure(str1(5) == '123454321', 'str1 test 2')
    ensure(str1(7) == '1234567654321', 'str1 test 3')
}

// 作业 5
// 实现函数
var str2 = function(n) {
    /*
    n 是 int
    返回这样规律的字符串, 特殊情况不考虑
    n       返回值
    1       'A'
    2       'ABA'
    3       'ABCBA'

    提示：
        和作业 4 类似，用两个循环来分别生成前半部分和前后部分

    分步提示：
        1. 定义一个字符串 s 来存储计算的结果，初始值为 ''
        2. 同作业 4 的处理方式，不同的是从 upper 里面用下标取出字母
            upper 是以前作业里的字符串，包含所有大写字母
        3. 同作业 4 的处理方式，不过需要注意循环从 n - 2 到 0
        4. 循环结束后 s 就是计算的结果，返回 s
    */
    // 可以用下标来获取字符, 这样就和上一题一样了
    var upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    var s = ''
    // 先左边
    for (var i = 0; i < n; i++) {
        s += upper[i]
    }
    // 再右边
    for (var i = n - 2; i >= 0; i--) {
        s += upper[i]
    }
    return s
}

var testStr2 = function() {
    ensure(str2(3) == 'ABCBA', 'str2 test 1')
    ensure(str2(5) == 'ABCDEDCBA', 'str2 test 2')
    ensure(str2(7) == 'ABCDEFGFEDCBA', 'str2 test 3')
}

// 作业 6
// 实现加法口诀表
var addLine = function(n) {
    var s = ''
    for (var i = 1; i <= n; i++) {
        // 模板字符串中是可以放一个表达式的
        // 会自动对表达式进行求值
        var n1 = `${n} + ${i} = ${n + i} `
        s += n1
    }
    return s
}
var addTable = function() {
    /*
    返回这样格式的加法口诀表(没写全, 但是要返回完整的)
    注意, 这只是我输入的内容
    实际上你普通 log 出来是不会有回车的
    [
        '1 + 1 = 2',
        '2 + 1 = 3  2 + 2 = 4',
        '3 + 1 = 4  3 + 2 = 5  3 + 3 = 6',
    ]

    提示：
        用一个辅助函数来生成行，然后在循环里面 push 这些行

    分步提示：
        1. 定义一个数组 table 来存储加法口诀表，初始值为 []
        2. 定义一个函数 addLine，接收参数 number，
            注意观察式子的规律，
            生成 `${number} + 1 = ${number + 1}` 到 `${number} + ${number} = ${number + number}` 的结果
            假设 number 为 3，结果就是
            3 + 1 = 4  3 + 2 = 5  3 + 3 = 6

        3. 循环从 0 开始，到 9 结束（包含 9），在每次循环里调用 addLine 函数，
            把调用结果 push 到 table 中
        4. 循环结束后 table 就是加法口诀表，但是这个目前是写在一行里面
            如果想要有回车，用作业 1 的函数 join('\n', addTable())
    */
    var r = []
    for (var i = 1; i < 10; i++) {
        var line = addLine(i)
        r.push(line)
    }
    return r
}

// 作业 7
// 实现函数
var range1 = function(start, end) {
    /*
    start end 都是 int

    返回一个 array, 假设 start 为 1, end 为 5, 返回数据如下
    [1, 2, 3, 4]

    提示：
        循环从 start 开始，end 结束（不包含 end），依次 push 到数组中

    分步提示：
        1. 循环从 start 开始，end 结束（不包含 end），
            每次循环的元素 push 到数组中
        2. 返回数组
    */
    var r = []
    for (var i = start; i < end; i++) {
        r.push(i)
    }
    return r
}

var testRange1 = function() {
    var test1 = range1(1, 5)
    var test2 = range1(3, 9)

    ensure(arrayEquals(test1, [1, 2, 3, 4]), 'range1 test 1')
    ensure(arrayEquals(test2, [3, 4, 5, 6, 7, 8]), 'range1 test 2')
}

// 作业 8
// 实现函数
var range2 = function(start, end, step=1) {
    /*
    start end step 都是数字
    step 是大于 0 的正整数

    返回一个 array
    假设 start=1, end=5, step=1 返回数据如下
    [1, 2, 3, 4]
    假设 start=0, end=6, step=2 返回数据如下
    [0, 2, 4]

    提示：
        类似作业 7，不同的是每次循环递增的不是 1，而是 step

    分步提示：
        1. 步骤和作业 7 类似，但是循环递增的是 step
        2. 返回数组
    */
    var r = []
    for (var i = start; i < end; i += step) {
        r.push(i)
    }
    return r
}

var testRange2 = function() {
    var test1 = range2(1, 5, 1)
    var test2 = range2(0, 6, 2)

    ensure(arrayEquals(test1, [1, 2, 3, 4]), 'range2 test 1')
    ensure(arrayEquals(test2, [0, 2, 4]), 'range2 test 2')
}

// 作业 9
// 实现函数
var stepCondition = function(current, end, step) {
    if (step > 0) {
        return current < end
        // 上面一行会被很多人写出两种失败的写法
        // if (current < end) {
        //     return true
        // } else {
        //     return false
        // }
        // 另一种写法叫做 三元表达式, 不要使用, 了解就好
        // return current < end ? true : false
    } else {
        return current > end
    }
}

var range3 = function(start, end, step=1) {
    /*
    start end step 都是数字

    和 range2 一样, 但是要求支持负数 step
    使用 while 循环
    返回一个 array
    假设 start=1, end=5, step=1 返回数据如下
    [1, 2, 3, 4]
    假设 start=6, end=0, step=-1 返回数据如下
    [6, 5, 4, 3, 2, 1]

    提示：
        判断 start 和 end 的大小，然后循环生成数组

    分步提示：
        1. 如果 start < end，调用作业 8 的 range2
        2. 否则，类似作业 8，循环从 start 开始，到 end 结束（不包括 end），每次递减 step
        3. 返回数组
    */
    // var r = []
    // if (start < end) {
    //     r = range2(start, end, step)
    // } else {
    //     for (var i = start; i > end; i += step) {
    //         r.push(i)
    //     }
    // }
    // return r

    // 或者用下面的解法
    var r = []
    var i = start
    while (stepCondition(i, end, step)) {
        r.push(i)
        i += step
    }
    return r
}

var testRange3 = function() {
    var test1 = range3(1, 5, 1)
    var test2 = range3(6, 0, -1)

    ensure(arrayEquals(test1, [1, 2, 3, 4]), 'range3 test 1')
    ensure(arrayEquals(test2, [6, 5, 4, 3, 2, 1]), 'range3 test 2')
}

// 作业 10
// 实现函数
var random01 = function() {
    /*
    js 标准数学库有一个随机数函数
    Math.random()
    它返回 0 - 1 之间的小数

    用它实现本函数, 返回 0 或 1

    提示：
        这道题目有多种实现方式，我们这里拿 Math.random() 与 0.5 比较

    分步提示：
        1. 如果 Math.random() > 0.5，返回 1
        2. 否则返回 0
    */
    // var n = Math.random()
    // if (n > 0.5) {
    //     return 1
    // } else {
    //     return 0
    // }

    // 另一种写法
    var n = Math.random()
    // * 10, 现在就是 0 - 10 之间的小数了
    n = n * 10
    // 取整, 这样就是 0 - 10 之前的整数了
    n = Math.floor(n)
    // 用余数来取得范围
    return n % 2
}

// 作业 11
// 实现函数
var randomLine01 = function(n) {
    /*
    返回一个只包含了 0 1 的随机 array, 长度为 n
    假设 n 为 5, 返回的数据格式如下(这是格式范例, 真实数据是随机的)
    [0, 0, 1, 0, 1]

    提示：
        循环 n 次，每次调用 random01，push 到数组中

    分步提示：
        1. 循环 n 次，每次调用 random01，把结果 push 到数组中
        2. 返回数组
    */
    var l = []
    for (var i = 0; i < n; i++) {
        var r = random01()
        l.push(r)
    }
    return l
}

// 作业 12
var randomSquare01 = function(n) {
    /*
    返回以下格式的数据
    假设 n 为 3, 返回的数据格式如下(这是格式范例, 真实数据是随机的)
    注意, 这只是一个 array, 并不是它显示的样子
    注意, 这是一个 array 不是 string
    [
        [0, 0, 1],
        [1, 0, 1],
        [0, 0, 0],
    ]
    返回, 包含了 n 个『只包含 n 个「随机 0 1」的 array』的 array

    提示：
        循环 n 次，每次调用 randomLine01，把结果 push 到数组中

    分步提示：
        1. 循环 n 次，每次调用 randomLine01，把结果 push 到数组中
        2. 返回数组
    */
    var l = []
    for (var i = 0; i < n; i++) {
        var r = randomLine01()
        l.push(r)
    }
    return l
}

// 作业 13
var randomLine09 = function(n) {
    /*
    返回一个只包含了 0 9 的随机 array, 长度为 n
    假设 n 为 5, 返回的数据格式如下(这是格式范例, 真实数据是随机的)
    [0, 0, 9, 0, 9]

    提示：
        先生成只包含 0 1 的数组，然后把数组里的 1 替换成 9

    分步提示：
        1. 调用函数 randomLine01 得到一个只包含 0 1 的数组 line
        2. 遍历这个数组，如果遍历出来的元素为 1，就把这个位置的元素值设置为 9
        3. 返回 line
    */
    var line = randomLine01(n)
    // 用循环把 1 都换成 9
    for (var i = 0; i < line.length; i++) {
        if (line[i] == 1) {
            line[i] = 9
        }
    }
    return line

    // 还没有一个巧妙的解法
    // var line = []
    // for (var i = 0; i < n; i++) {
    //     var r = random01()
    //     var e = [0, 9][r]
    //     line.push(e)
    // }
    // return line
}

// 作业 14
var markedLine = function(array) {
    /*
    array 是一个只包含了 0 9 的 array
    返回一个标记过的 array
    ** 注意, 使用一个新数组来存储结果, 不要直接修改老数组
    复制数组用 array.slice(0) 实现

    标记规则如下
    对于下面这样的 array
    [0, 0, 9, 0, 9]
    标记后是这样
    [0, 1, 9, 2, 9]

    规则是, 0 会被设置为左右两边 9 的数量

    提示：
        把 9 左右加 1，注意判断 9 是否在两边

    分步提示：
        1. 先使用 array.slice(0) 复制数组 array，用变量 line 存储
        2. 遍历数组 line，每次遍历的元素是 n
        3. 如果 n 为 9，并且 n 不是第一个元素，也不是最后一个元素
        4. 如果 n 左边的数字不是 9，把 n 左边的数字 + 1
        5. 如果 n 右边的数字不是 9，把 n 右面的数字 + 1
        6. 返回数组 line
    */
    // 判断 9 左边有没有元素
    // 判断 9 左边是不是 9
    var line = array.slice(0)
    for (var i = 0; i < line.length; i++) {
        var n = line[i]
        // 如果是 9, 左边 +1
        if (n == 9 && i > 0) {
            if (line[i - 1] != 9) {
                line[i - 1] += 1
            }
        }
        // 如果是 9, 右边 +1
        if (n == 9 && i < line.length - 1) {
            if (line[i + 1] != 9) {
                line[i + 1] += 1
            }
        }
    }
    return line
}

var testMarkedLine = function() {
    var test1 = markedLine([0, 0, 9, 0, 9])
    var test2 = markedLine([0, 9, 0, 9, 0])

    ensure(arrayEquals(test1, [0, 1, 9, 2, 9]), 'marked line test 1')
    ensure(arrayEquals(test2, [1, 9, 2, 9, 1]), 'marked line test 2')
}

// 作业 15
// 注意, 这道题比较麻烦, 你要是不会, 就暂时放弃
var clonedSquare = function(array) {
    var s = []
    for (var i = 0; i < array.length; i++) {
        var line = array[i]
        var l = line.slice(0)
        s.push(l)
    }
    return s
}

var plus1 = function(array, x, y) {
    // 1. array[x][y] 不能是 9
    // x 和 y 要符合条件, 不能越界
    var n = array.length
    if (x >= 0 && x < n && y >= 0 && y < n) {
        if (array[x][y] != 9) {
            array[x][y] += 1
        }
    }
}

var markAround = function(array, x, y) {
    /*
    ###
    #*#
    ###
    */
    if (array[x][y] == 9) {
        // 标记周围 8 个
        // 标记的时候还需要判断是不是可以标记
        // 比如要标记左上角, 要判断 x > 0, y > 0
        // 这种判断很麻烦, 我们直接用函数来做
        // 具体的处理逻辑扔给函数

        // 先标记左边 3 个
        plus1(array, x - 1, y - 1)
        plus1(array, x - 1, y)
        plus1(array, x - 1, y + 1)

        // 标记中间 2 个
        plus1(array, x, y - 1)
        plus1(array, x, y + 1)

        // 标记右边 3 个
        plus1(array, x + 1, y - 1)
        plus1(array, x + 1, y)
        plus1(array, x + 1, y + 1)
    }
}

var markedSquare = function(array) {
    /*
    array 是一个「包含了『只包含了 0 9 的 array』的 array」
    返回一个标记过的 array
    ** 注意, 使用一个新数组来存储结果, 不要直接修改老数组

    范例如下, 这是 array
    [
        [0, 9, 0, 0],
        [0, 0, 9, 0],
        [9, 0, 9, 0],
        [0, 9, 0, 0],
    ]

    这是标记后的结果
    [
        [1, 9, 2, 1],
        [2, 4, 9, 2],
        [9, 4, 9, 2],
        [2, 9, 2, 1],
    ]

    规则是, 0 会被设置为四周 8 个元素中 9 的数量

    提示：
        这道题比较麻烦, 你要是不会, 就直接写「这道题目我不会」

    分步提示：
        1. 先定义一个 clonedSquare 函数，把 array 的内容复制到一个新数组中
        2. 调用 clonedSquare 函数，得到 square
        3. 遍历 square，每次遍历的元素为 line
        4. 遍历 line，调用一个 markAround 函数，传入 square, i, j
        5. 实现 markAround 函数，对于每一个 square[i][j] 这样的元素都按照规则 +1
            分 4 个顶角、4 条边和剩下的元素这几种情形
        6. 两重遍历结束后，square 就是需要的结果，return square 即可。
    */
    var square = clonedSquare(array)
    for (var i = 0; i < square.length; i++) {
        var line = square[i]
        for (var j = 0; j < line.length; j++) {
            markAround(square, i, j)
        }
    }
    return square
}

// 作业 10
// 10 分钟做不出就看提示
//
var replace = function(s, old_str, new_str) {
    /*
    3 个参数 s old_str new_str 都是字符串
    返回一个「将 s 中的 old_str 字符串替换为 new_str 字符串」的字符串
    假设 old 存在并且只出现一次

    返回 string

    提示:
    找到指定旧字符串的起始下标, 将其前后字符串与新字符串进行拼接

    分步提示:
    1. 为了计算 old 在 s 中的起始下标, 在 replace 函数前构建辅助函数 findIndex, findIndex 包含两个参数, s1 和 s2, 作用是找到 s2 在 s1 中的起始下标
        计算 s2 的长度 len
        建立循环, 从左到右遍历 s1 中的字符
        循环中, 从 s1 中切割出长度为 len 的字符串, 切割起点为当前遍历到的字符
        如果切割出的字符串与 s2 相同, 返回当前遍历到字符的下标
    2. 使用 s 和 old 作为参数调用 findIndex 函数, 得到 old 的起始下标 index
    3. 利用 index 切割字符串, 得到 s 中 old 前的字符串 head
    4. 计算 old 的长度 oldLen, 并利用 oldLen 和 index 切割字符串, 得到 s 中 old 后的字符串 tail
    5. 按顺序依次拼接 head, newString, tail, 并返回结果
    */
    /*
    0123
    a==b
    */
    // 首先找到下标
    var length = old_str.length
    for (var i = 0; i < s.length; i++) {
        var c = s.slice(i, i + length)
        // c 可能不是我们想要的结果, 所以 log 一下
        // log 是非常重要的, 一定要掌握
        log('replace for', c)
        if (c == old_str) {
            // 切片拼接字符串
            var left = s.slice(0, i)
            var right = s.slice(i + length, s.length)
            // log('left and right', left, right, right.length)
            // log('index', i, length)
            var r = left + new_str + right
            return r
        }
    }
}

// 测试函数自行添加
var testReplace = function() {
    // ensure(replace('a#b', '#', '.') == 'a.b', 'replace test 1')
    ensure(replace('a==b', '==', '&') == 'a&b', 'replace test 2')
    // ensure(replace('hello gua', 'gua', 'there') == 'hello there', 'replace test 3')
}

var e = function(selector) {
    var element = document.querySelector(selector)
    return element
}

var charIsLetter = function(s) {
    var letter = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    return letter.includes(s)
}

var charIsLetterOrDigit = function(s) {
    var digits = '0123456789'
    return charIsLetter(s) || digits.includes(s)
}

var stringCheck = function(name) {
    var others = '_'
    for (var i = 0; i < name.length; i++) {
        var c = name[i]
        if (!charIsLetterOrDigit(c) && !others.includes(c)) {
            return false
        }
    }
    return true
}

var bindEventLogin = function() {
    var button = e('#id-button-login')
    button.addEventListener('click', function() {
        log('登录按钮 click')
        // 检查用户名合法性
        var input = e('#id-input-name')
        var name = input.value
        // 检查第一位
        var c = name[0]
        var validChar = charIsLetter(c)
        // 检查最小长度
        var validLength = name.length >= 2
        // 1，只能字母或数字结尾
        var tail = name[name.length - 1]
        var validTail = charIsLetterOrDigit(tail)
        // 2，最大长度10
        var validMaxLength = name.length <= 10
        // 3，只能包含字母、数字、下划线
        var validString = stringCheck(name)
        log('debug validString', validString)

        var valid = validChar && validLength && validTail && validMaxLength && validString
        var label = e('h3')
        if (valid) {
            label.innerHTML = '检查合格'
        } else {
            label.innerHTML = '检查失败'
        }
    })
}

// 作业 8
// 做不出尽早看提示或者到群里讨论或者发帖
//
var discount = function(price, grade) {
    /*
    price 是一个 int
    grade 合法情况下一共 6 种取值, 还可能没有给出这个参数
        '小学生'
        '初中生'
        '高中生'
        '大学生'
        '研究生'
    对应的折扣分别是 5 6 7 8 9

    注意, 如果调用者没有给出 grade 参数, 没有折扣

    返回折扣后的价格


    分步提示：
        1. 使用对象(object) d 存储数据，
            key 分别为 '小学生' '初中生' '高中生' '大学生' '研究生'，
            value 分别为 5 6 7 8 9
        2. 传入的 grade 作为 key，判断 key 是否在 d 里面，如果在的话，取出对应的 value
        3. 如果不在里面，则没有折扣
    */
    // 最简单的就是用 if 的方法
    // 大家都能理解的办法, 6 个 if else
    // if (grade == '小学生') {
    //     return price * 0.5
    // } else if (grade == '初中生') {
    //     return price * 0.6
    // } else if (grade == '高中生') {
    //     return price * 0.7
    // }

    // 这种用字典解决很多个 if else 的问题的方法叫做表驱动法
    // <代码大全> 第 18 章
    // CSS 深入学习: https://www.zhihu.com/question/61174554/answer/185530348
    var d = {
        '小学生': 0.5,
        '初中生': 0.6,
        '高中生': 0.7,
        '大学生': 0.8,
        '研究生': 0.9,
    }
    var discountForGrade = d[grade]
    // 如果没有传入 grade
    if (grade == undefined) {
        discountForGrade = 1
    }
    return price * discountForGrade
}


var __main = function() {
    // testJoin()
    // testSplit()
    // testReplaceAll()
    // testStr1()
    // testStr2()
    // log('add table', addTable())
    // testRange1()
    // testRange2()
    // testRange3()
    // testMarkedLine()

    var array = [
        [0, 9, 0, 0],
        [0, 0, 9, 0],
        [9, 0, 9, 0],
        [0, 9, 0, 0],
    ]
    // log(markedSquare(array))

    // testReplace()
    // bindEventLogin()

    log(discount(10, '大学生'))
    log(discount(10))
}

__main()
