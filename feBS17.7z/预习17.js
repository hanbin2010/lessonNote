// 今天上课的主要内容有
//
// 用 node.js 开发脱离浏览器的 js 程序
// （主要用于工具或者服务端，比如文件处理）
//
// 用 express 简述后端开发的流程
// （前端和后端配合工作，了解一下后端是很有好处的）
//
// npm(node package manager)
// package 就是我们之前说的库, 比如 bootstrap


//
// express 框架安装使用(它是一个流行的基于 nodejs 的服务器开发框架)
yarn add express

/*
在命令行中 cd 到你的项目文件夹中
使用下面的命令来安装 express
yarn add express

装好后, 会多出下面几个文件/文件夹
node_modules            这个目录存放了本工程中所有通过 yarn add 安装的库
package.json            这个文件记录了所有安装的库的名字
yarn.lock               记录了依赖的库的具体版本信息
*/
