var a = 'hello'
console.log(a, ' gua')

var fs = require('fs')
fs.readdir('.', (error, files) => {
    console.log(typeof error, error)
    if (error != null) {
        console.log(error)
    } else {
        console.log('files', files)
    }
})

var file = 'message.txt'
fs.unlink(file, (error) => {
    if (error != null) {
        // log('error', error, error.path)
    } else {
        console.log(`${file} 成功删除`)
    }
})

// fs.writeFile('message.txt', '你好 Node.js', (error) => {
//   if (error != null) {
//       throw err
//   }
//   console.log("It's saved!")
// })
