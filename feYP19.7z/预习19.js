/*
fe19

本次内容如下

同步与异步
古代的 js 异步解决方案 promise
我的异步解决方案 guasync
lodash
jquery
闭包
*/
