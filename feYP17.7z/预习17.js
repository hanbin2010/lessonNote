// 今天上课的主要内容有
//
// 用 node.js 开发脱离浏览器的 js 程序
// （主要用于工具或者服务端，比如文件处理）
//
// 用 express 简述后端开发的流程
// （前端和后端配合工作，了解一下后端是很有好处的）
//
// npm(node package manager)
// package 就是我们之前说的库, 比如 bootstrap


//
// express 框架安装使用(它是一个流行的基于 nodejs 的服务器开发框架)
