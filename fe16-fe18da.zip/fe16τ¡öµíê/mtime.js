// 引用（导入）两个必需库
const request = require('sync-request')
const cheerio = require('cheerio')
// 先引入 fs
const fs = require('fs')

class Movie {
    constructor() {
        // 分别是电影名、评分、简介、排名、封面图片链接
        this.name = ''
        this.score = 0
        this.introduction = ''
        this.ranking = 0
        this.coverUrl = ''
    }
}

const log = console.log.bind(console)

const cachedUrl = (url) => {
    //确定缓存的文件名
    var first = url.split('-')[1]
    if (first == undefined) {
        var cacheFile = 'cached_html/' + '1.html'
    } else {
        var cacheFile = 'cached_html/' + url.split('-')[1]
    }
    // 检查缓存文件是否存在
    var exists = fs.existsSync(cacheFile)
    // 存在即返回对应 data，不存在则获取页面并返回
    if (exists) {
        var data = fs.readFileSync(cacheFile)
        return data
    } else {
        // 用 GET 方法获取url链接的内容（ html ），r 为一个 response，而非数据
        var r = request('GET', url)
        // utf-8 是网页文件的文本编码，对响应使用getBody方法得到相应格式数据
        var body = r.getBody('utf-8')
        fs.writeFileSync(cacheFile, body)
        return body
    }
}

const movieFromItem = (item) => {
    var e = cheerio.load(item)

    var movie = new Movie()
    // 时光网的每个电影都分成四个div：number、mov_pic、mov_con、mov_point；
    // 分别对应 序号、海报、内容和评分
    movie.ranking = e('.number').text()
    movie.coverUrl = e('.mov_pic').find('img').attr('src')

    var content = e('.mov_con')
    movie.name = content.find('h2').text()
    movie.introduction = content.find('.mt3').text()
    movie.score = e('.point').text()

    return movie
}

const moviesFromUrl = (url) => {
    var body = cachedUrl(url)
    var e = cheerio.load(body)
    var items = e('#asyncRatingRegion').find('li')
    var movies = []
    for (var i = 0; i < items.length; i++) {
        var item = items[i]
        var m = movieFromItem(item)
        movies.push(m)
    }
    return movies
}

const saveMovie = (movies) => {
    // 生成带有缩进模式的 json 数据，movies 数据为一个数组
    var s = JSON.stringify(movies, null, 2)
    // 把 json 格式字符串写入到文件中
    var fs = require('fs')
    var path = 'mtime.txt'
    fs.writeFileSync(path, s)
}

const downloadCovers = (movies) => {
    for (var i = 0; i < movies.length; i++) {
        // 每个电影的图片地址
        var m = movies[i]
        var url = m.coverUrl
        // 图片的存储路径及文件名
        var path = 'covers/' + m.ranking + '. ' + m.name + '.jpg'

        var r = request('GET', url)
        var img = r.getBody()
        fs.writeFileSync(path, img)
    }
}
const __main = () => {
    var movies = []
    for (var i = 0; i < 10; i++) {
        var url = 'http://www.mtime.com/top/movie/top100/'
        if (i > 0) {
            url = url + `index-${i + 1}.html`
        }
        var moviesInPage = moviesFromUrl(url)
        movies = [...movies, ...moviesInPage]
    }
    log('movie', movies)
    saveMovie(movies)
    downloadCovers(movies)
}

__main()