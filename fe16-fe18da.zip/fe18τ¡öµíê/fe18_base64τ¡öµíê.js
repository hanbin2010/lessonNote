// 定义我们的 log 函数
var log = console.log.bind(console)


// ======
// 测试
// ======
//
// 定义我们用于测试的函数
// ensure 接受两个参数
// condition 是 bool, 如果为 false, 则输出 message
// 否则, 不做任何处理
var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if (!condition) {
        log('*** 测试失败:', message)
    }
}

// 作业 1
//
var ascii = function(char) {
    /*
    char 是一个长度为 1 的 string
    这个函数返回这个字符的 ASCII 码

    这个答案用到了 s.charCodeAt(index) 函数, 例子如下
    'A'.charCodeAt(0) 返回 65
    'a'.charCodeAt(0) 返回 97

    字符在电脑中的存储是以数字的方式
    每个字符其实是用一个数字代表的, 这个方式叫做编码
    ASCII 码是一个通用的编码, 包含英文字符数字和常见符号

    这个作业答案我给了, 理解一下这件事就好, 不懂搜一下
    */
    return char.charCodeAt(0)
}

const testAscii = () => {
    ensure(ascii('A') == 65, 'test ascii 1')
    ensure(ascii('a') == 97, 'test ascii 2')
    log('test ascii 成功')
}

// 作业 2
//
var charFromAscii = function(code) {
    /*
    code 是一个 int
    返回 code 所表示的字符

    这个答案用到了 String.fromCharCode(code) 函数, 例子如下
    String.fromCharCode(97) 返回 'a'
    String.fromCharCode(65) 返回 'A'
    */
    return String.fromCharCode(code)
}

const testCharFromAscii = () => {
    ensure(charFromAscii(97) == 'a', 'test char from code 1')
    ensure(charFromAscii(65) == 'A', 'test char from code 2')
    log('test char from code 成功')
}

// 作业 3
//
var zerofill = function(str) {
    var char = '0'
    while (str.length < 8) {
        str = char + str
    }
    return str
}

var reverse = function(str) {
    var s = ''
    var len = str.length
    for (var i = len - 1; i >= 0; i--) {
        s += str[i]
    }
    return s
}

var binary = function(n) {
    /*
    n 是一个不大于 255 的 int
    返回 n 的 8 位二进制形式的字符串
    例如 binary(7) 返回 '00000111'

    进制转换自行搜索或者论坛提问大家讨论吧
    */
    // JS 内置的 toString 函数可以直接按照进制转换
    // 比如 7 转成 2 进制就是 (7).toString(2), 结果是 '111'
    // 注意数字 7 左右加上了括号
    // 我们相当于实现这个函数
    var s = ''
    var sum = 0
    while (n > 0) {
        var num = n % 2
        n = Math.floor(n / 2)
        // 这样加出来的 s 是 111, 要 reverse
        s += String(num)
    }
    s = reverse(s)
    var str = zerofill(s)
    return str
}

var testBinary = () => {
    ensure(binary(7) == '00000111', 'test binary 1')
    ensure(binary(255) == '11111111', 'test binary 2')
    ensure(binary(100) == '01100100', 'test binary 3')

    log('test binary 成功')
}

// 作业 4
//
var int = function(bin) {
    /*
    bin 是一个 8 位二进制形式的字符串
    返回 bin 代表的数字
    例如 int('00000111') 返回 7

    进制转换自行搜索或者论坛提问大家讨论吧
    */
    var sum = 0
    var len = bin.length
    for (var i = 0; i < len; i++) {
        var b = bin[len - i - 1]
        var n = Number(b)
        // 2 ** i 是指 2 的 i 次方, 是 es7 的语法
        // 相当于 Math.pow(2, i)
        sum += n * 2 ** i
    }
    return sum
}

var testInt = function() {
    ensure(int('00000111') == 7, 'test int 1')
    ensure(int('01100100') == 100, 'test int 2')
    ensure(int('11111111') == 255, 'test int 3')

    log('test int 成功')
}

var binaryStream = function(s) {
    /*
    s 是一个 string
    返回 s 的二进制字符串
    例如 binaryStream('Man') 返回
    '010011010110000101101110'

    使用上面的函数
    */
    var result = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        var code = ascii(c)
        var b = binary(code)
        result += b
    }
    return result
}

var testBinaryStream = function() {
    ensure(binaryStream('Man') == '010011010110000101101110', 'test binary stream 1')
    ensure(binaryStream('is') == '0110100101110011', 'test binary stream 2')
    log('test binary stream 成功')
}

var stringFromBinary = function(bins) {
    /*
    bins 是一个二进制形式的字符串
    返回 bins 代表的原始字符串
    例如 stringFromBinary('010011010110000101101110') 返回 'Man'

    使用上面的函数
    */
    var s = ''
    for (var i = 0; i < bins.length; i += 8) {
        var bin = bins.slice(i, i + 8)
        var n = int(bin)
        var c = charFromAscii(n)
        s += c
    }
    return s
}

var testStringFromBinary = function() {
    ensure(stringFromBinary('010011010110000101101110') == 'Man', 'test string from binary 1')
    ensure(stringFromBinary('0110100101110011') == 'is', 'test string from binary 2')
    log('test string from binary 成功')
}

// 作业 7
//
var base64Encode = function(s) {
    /*
    s 是一个 string
    返回 s 的 base64 编码

Base64是一种基于 64 个可打印字符来表示数据的方法
它用每 6 个比特为一个单元，对应某个可打印字符
ASCII 码一个字符是 8 比特, 也就是一字节
3 个字节就有 24 个比特, 对应了 4 个 base64 单元

如下所示
原始信息        M            a           n
ASCII         77            7           110
二进制         01001101     01100001     01101110
4 个单元       010011     010110     000101     101110
每个单元转换后  19         22         5          46

转换后每个 base64 单元都是一个 0-63 的数字
因为 6 比特表示的范围就是这么大
然后数字到字符串的转换是下面这段字符串取下标所得
'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

19 对应的是 T
22 对应的是 W
5 对应的是  F
46 对应的是 u
那么 Base64 编码结果就是    T   W   F  u

所以 base64Encode('Man') 返回 'TWFu'


既然 3 个字节转换为 4 个 base64 单元
那么 1 个字节怎么办呢?
答案是用 0 补出 3 字节(这样就可以凑满 24 位, 也就可以分成 4 个单元), 如下所示
原始信息    M
ASCII     77           0            0
二进制     01001101     00000000     00000000
4 个单元   010011     010000     000000     000000
单元转换后  19 16 0 0
因为末尾是强行补上的, 所以给他用 '=' 凑出字符(这是一个例外)
所以 base64Encode('M') 返回 'TQ=='
    */
    var ma64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    var bins = binaryStream(s)
    // 如果 bins 的长度不是 24 的倍数, 就用 '0' 补到 24 的倍数
    var char = '0'
    while (bins.length % 24 != 0) {
        bins += char
    }

    // log('bins', bins)

    var s = ''
    for (var i = 0; i < bins.length; i += 6) {
        var bit6 = bins.slice(i, i + 6)
        var n = int(bit6)
        if (n > 0) {
            s += ma64[n]
        } else {
            s += '='
        }
    }
    return s
}

var testBase64Encode = function() {
    ensure(base64Encode('Man') == 'TWFu', 'test base64 encode 1')
    ensure(base64Encode('M') == 'TQ==', 'test base64 encode 2')
    ensure(base64Encode(' is') == 'IGlz', 'test base64 encode 3')
    log('test base64 encode 成功')
}

// 作业 8
//
var base64Decode = function(s) {
    /*
    s 是一个 base64 编码后的字符串
    解码 s 并返回
    例如 base64Decode('TWFu') 返回 'Man'
    */
    var ma64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

    var bits = ''
    for (var i = 0; i < s.length; i++) {
        var c = s[i]
        // indexOf 和以前作业实现的 find 函数作用是一致的
        var index = ma64.indexOf(c)
        // 如果没有找到, 说明对应的是 0
        if (index == -1) {
            index = 0
        }
        var bin = binary(index)
        var bit6 = bin.slice(2, 8)
        bits += bit6
    }

    var str = ''
    for (var i = 0; i < bits.length; i += 8) {
        var bit8 = bits.slice(i, i + 8)
        var code = int(bit8)
        // 如果 code 为 0, 说明是补充的, 这种情况下直接跳过
        // 所以只需要处理不为 0 的情况
        if (code != 0) {
            var c = charFromAscii(code)
            str += c
        }
    }

    return str
}

var testBase64Decode = function() {
    ensure(base64Decode('TWFu') == 'Man', 'test base64 decode 1')
    ensure(base64Decode('TQ==') == 'M', 'test base64 decode 2')
    ensure(base64Decode('IGlz') == ' is', 'test base64 decode 3')

    log('test base64 decode 成功')
}

const __main = () => {
    testAscii()
    testCharFromAscii()
    testBinary()
    testInt()
    testBinaryStream()
    testStringFromBinary()
    testBase64Encode()
    testBase64Decode()
}

__main()
