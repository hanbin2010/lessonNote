import React from 'react'
import logo from './logo.svg'
import './App.css'

import Message from './message'
import Timer from './timer'
import TodoApp from './todo'
import MarkdownEditor from './editor'


// 程序的主入口
// class 是 es6 的语法
class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      showTimer: true,
      style: {},
    }
  }

  render() {
    // 用一个变量来决定是否显示 timer 组件
    // 下面的语法是 三元表达式
    // a ? b : c 的意思是, 如果 a 是 true 则结果是 b 否则是 c
    var timer = this.state.showTimer ? <Timer /> : null
    var style = this.state.style
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Welcome to React</h2>
        </div>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and reload.
        </p>
        <Message name='gua' />
        <Message name='瓜' />
        <button onClick={this.handleToggleTimer} style={style}>开关 timer </button>
        {timer}
        <TodoApp />
        <MarkdownEditor />
      </div>
    )
    // *** 需要注意的是, 组件必须 /> 结尾, 规定
  }

  handleToggleTimer = (e) => {
    // console.log('handleToggleTimer', this.state.showTimer)
    var show = !this.state.showTimer
    // this.setState 之后, state 就会发生变化
    // 一旦 state 发生变化, react 就会调用 render 函数
    // 调用 render 函数, 就可以会影响到 return 里面的内容
    // return 的内容决定了页面怎么显示, 所以也就影响到了页面怎么显示

    // 注意, setState 是一个异步函数
    var background = 'red'
    if (show) {
        background = 'blue'
    }
    var style = {
        background: background,
    }
    this.setState({
        showTimer: show,
        style: style,
    })
  }
}

export default App
