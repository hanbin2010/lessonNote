// 定义我们的 log 函数
var log = console.log.bind(console)


// ======
// 测试
// ======
//
// 定义我们用于测试的函数
// ensure 接受两个参数
// condition 是 bool, 如果为 false, 则输出 message
// 否则, 不做任何处理
var ensure = function(condition, message) {
    // 在条件不成立的时候, 输出 message
    if(!condition) {
        log('*** 测试失败:', message)
    }
}


// 作业 1
//
var isPrime = function(n) {
    /*
    n 是 int
    判断 n 是否是素数(质数)
    */
    // 质数的定义是 只能被 1 和自身整除的数字
    // 所以最简单的算法是从 2 到 n 检查是否能被整除
    for (var i = 2; i < n; i++) {
        if (n % i == 0) {
            return false
        }
    }
    // 循环结束都没返回的话说明 n 是质数
    return true
}

// 作业 2
//
var primeNumbers = function() {
    /*
    返回 100 内的素数列表
    */
    var numbers = []
    for (var i = 2; i < 100; i++) {
        // 直接使用上面写好的函数检查
        if (isPrime(i)) {
            numbers.push(i)
        }
    }
    return numbers
}


// 作业 3
//
var capString = function(str) {
    /*
    给定一个英文句子 str（一个只有字母的字符串）
    例子如下, 单词之间有空格隔开
    'thank you very much'
    返回「将句中所有单词变为有且只有首字母大写的形式」的 string
    */
    // 先将 str 转换为完全小写字符串
    // lowercase uppercase 使用作业 4 的函数, 实现请看 作业 4
    var s1 = lowercase(str)
    // split join 是作业 7 的函数
    var words = split(s, ' ')
    // for 循环让 words 中的单词首字母大写
    var titles = []
    for (var i = 0; i < words.length; i++) {
        var w = words[i]
        var cap = uppercase(w.slice(0, 1)) + w.slice(1)
        titles.push(cap)
    }
    var s2 = join(titles, ' ')
    return s2
}


// 作业 4
//
var letterCount = function(str) {
    /*
    给定一个只包含字母的字符串，返回单个字母出现的次数
    考察字典的概念和使用
    返回值为包含数组的数组，格式如下（对数组中数组的顺序不做要求）

    // 可以使用 Object.keys 函数
    var obj = {
      foo: 1,
      bar: 2,
    }
    Object.keys(obj)
    ["foo", "bar"]

    参数 "hello"
    返回值 [['h', 1], ['e', 1], ['l', 2], ['o', 1]]
    */
    // 创建一个空对象来存储
    var count = {}
    for (var i = 0; i < str.length; i++) {
        var c = str[i]
        var keys = Object.keys(count)
        if (keys.includes(c)) {
            // 如果存在, 直接 +1
            count[c] += 1
        } else {
            // 如果不存在, 设置为 1
            count[c] = 1
        }
    }
    return count
}


// 作业 5
//
var queryFromObject = function(param) {
    /*
    param 是一个 object
    例子如下
    param 是 {
        'foo': 1,
        'bar': 'far',
    }
    返回如下 string, 顺序不做要求(foo bar 的顺序)
    foo=1&bar=far

    注意, 使用 Object.keys 函数
    */
    // kvs 意思是 keyvalues
    var kvs = []
    var keys = Object.keys(param)[i]
    for (var i = 0; i < Object.keys(param).length; i++) {
        var key = keys[i]
        var value = param[key]
        var kv = key + '=' + value
        kvs.push(kv)
    }
    // 字符串也有一个 join 函数, 和老作业中的 join 一样
    var query = kvs.join('&')
    return query
}


// 作业 6
//
var argsFromQuery = function(queryString) {
    /*
    queryString 是一个 string
    例子如下
    queryString 是 foo=1&bar=far
    返回如下 object, 顺序不做要求(foo bar 的顺序)
    {
        'foo': '1',
        'bar': 'far',
    }
    */
    // 字符串也有一个 split 函数, 和老作业中的 split 一样
    var args = {}
    var kvs = queryString.split('&')
    for (var i = 0; i < kvs.length; i++) {
        var kv = kvs[i]
        var key = kv.split('=')[0]
        var value = kv.split('=')[1]
        args[key] = value
    }
    return args
}
