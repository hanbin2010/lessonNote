// 今天上课的主要内容有
//
// 类 与 面向对象（OO，Object Oriented）
// js 的大坑 this 关键字
// bind call apply
// 更好的 ajax 封装（用 object 当参数，用 OO 的方式来封装 todo api）
//
// 应该能看懂一部分，不懂的稍微做个笔记，等上课讲解
