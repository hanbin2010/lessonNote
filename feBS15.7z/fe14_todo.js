var log = console.log.bind(console)

var e = selector => document.querySelector(selector)

var appendHtml = (element, html) => element.insertAdjacentHTML('beforeend', html)

var ajax = function(method, path, data, callback) {
    var r = new XMLHttpRequest()
    r.open(method, path, true)
    r.setRequestHeader('Content-Type', 'application/json')
    r.onreadystatechange = function() {
        if (r.readyState == 4) {
            callback(r.response)
        }
    }
    r.send(data)
}

// 1. 往页面中添加输入框和提交按钮来增加 todo
//     添加页面元素
//     点击提交后, 发数据给 api, api 如果成功, 则在页面中显示被创建的 todo
var insertInput = () => {
    var t = `
        <div>
            <input id="id-input-task">
            <button id="id-button-add" class="todo-add">add button</button>
        </div>
    `
    var element = e('#id-div-todo-container')
    appendHtml(element, t)
}

var templateTodo = (todo) => {
    var task = todo.task
    var id = todo.id
    var t = `
        <div class="todo-cell" data-id="${id}">
            <button class="todo-edit">编辑</button>
            <button class="todo-delete">删除</button>
            <span class="todo-task">${task}</span>
        </div>
    `
    return t
}

var insertTodo = (todo) => {
    var container = e('#id-div-todo-container')
    var html = templateTodo(todo)
    appendHtml(container, html)
}

var insertTodos = (todos) => {
    for (var i = 0; i < todos.length; i++) {
        var todo = todos[i]
        insertTodo(todo)
    }
}

var apiGet = (path, callback) => {
    var url = 'https://vip.kybmig.cc/sandbox/todo/3587405093' + path
    ajax('GET', url, '', function(r) {
        var data = JSON.parse(r)
        callback(data)
    })
}

var apiPost = (path, data, callback) => {
    var url = 'https://vip.kybmig.cc/sandbox/todo/3587405093' + path
    data = JSON.stringify(data)
    ajax('POST', url, data, function(r) {
        var response = JSON.parse(r)
        callback(response)
    })
}

var apiTodoAll = (callback) => {
    var path = '/all'
    apiGet(path, callback)
}

var apiTodoAdd = (data, callback) => {
    var path = '/add'
    apiPost(path, data, callback)
}

var apiTodoUpdate = (todoId, data, callback) => {
    var path = '/update/' + todoId
    apiPost(path, data, callback)
}

var apiTodoDelete = (todoId, callback) => {
    var path = '/delete/' + todoId
    apiGet(path, callback)
}

// var bindEventAdd = () => {
//     // 绑定 add 按钮的事件委托
//     var container = e('#id-div-todo-container')
//     container.addEventListener('click', (event) => {
//         var self = event.target
//         if (self.classList.contains('todo-add')) {
//             log('button click add')
//             // 获取 input 的输入
//             var input = e('#id-input-task')
//             var value = input.value
//             // 组装成对象
//             var data = {
//                 task: value,
//             }
//             apiTodoAdd(data, (todo) => {
//                 log('创建成功', todo)
//                 // 往页面中插入被创建的 todo
//                 insertTodo(todo)
//             })
//         }
//     })
// }

var bindEventDelete = () => {
    // 绑定 delete 按钮的事件委托
    var container = e('#id-div-todo-container')
    container.addEventListener('click', (event) => {
        var self = event.target
        if (self.classList.contains('todo-delete')) {
            log('button click delete')
            var todoCell = self.closest('.todo-cell')
            // 拿到 todo id
            //在事件中调用删除函数, 获取 todo_id 并且传给删除函数
            // 用 ajax 发送给服务器
            var todoId = todoCell.dataset.id
            apiTodoDelete(todoId, (todo) => {
                log('删除成功', todo)
                // 删除后, 删除页面元素
                todoCell.remove()
            })
        }
    })
}

var bindEventEdit = () => {
    // 绑定 edit 按钮的事件委托
    var container = e('#id-div-todo-container')
    container.addEventListener('click', (event) => {
        var self = event.target
        if (self.classList.contains('todo-edit')) {
            log('button click edit')
            // 找到 todo-task, 设置 contenteditable 属性, 并且让它获得焦点
            var todoCell = self.closest('.todo-cell')
            var task = todoCell.querySelector('.todo-task')
            task.contentEditable = true
            task.focus()
        }
    })
}

var bindEventUpdate = () => {
    var container = e('#id-div-todo-container')
    // 绑定 keydown 事件, 当用户按键的时候触发
    container.addEventListener('keydown', (event) => {
        var self = event.target
        if (self.classList.contains('todo-task')) {
            // 判断按下的是否为 回车键
            if (event.key == 'Enter') {
                log('按了回车键', event)
                // 取消事件的默认行为, 回车键在编辑标签内容的时候会默认换行
                event.preventDefault()
                self.contentEditable = false
                var todoCell = self.closest('.todo-cell')
                var todoId = todoCell.dataset.id
                var data = {
                    task: self.innerHTML,
                }
                apiTodoUpdate(todoId, data, (todo) => {
                    log('更新成功', todo)
                })
            }
        }
    })
}

// 载入所有的 todos 并插入到页面中
var loadTodos = () => {
    apiTodoAll(function(todos) {
        log('todos', todos)
        insertTodos(todos)
    })
}

var actionAdd = () => {

}

var bindEventsDelegates = () => {
    var container = e('#id-div-todo-container')
    container.addEventListener('click', (event) => {
        var self = event.target
        if (self.classList.contains('todo-add')) {
            actionAdd(event)
        } else if (self.classList.contains('todo-delete')) {

        } else if () {

        }
    })
}

var bindEvents = () => {
    bindEventAdd()
    bindEventDelete()
    bindEventEdit()
    bindEventUpdate()

    bindEventsDelegates()
}

var insertCss = () => {
    var t = `
        <style>
            .todo-cell {
                outline: 1px dashed red;
            }
        </style>
    `
    // 注意, document.head 相当于 e('.head')
    // document.head 和 docoument.body 是直接可以访问的元素
    // 因为这两个元素很特殊
    var element = document.head
    appendHtml(element, t)
}

// 这是一个箭头函数
var __main = () => {
    // 初始化程序, 插入 input 标签
    insertInput()
    insertCss()
    // 绑定事件委托
    bindEvents()
    // 载入所有 todos 并且在页面中显示
    loadTodos()
}

__main()
