HTML 部分
localStorage 和 cookies
// localStorage、 sessionStorage 与 cookies 的区别

FormData
// 上传文件需要用到这个对象

File API
// 预览图片使用




CSS 部分
float
position
display
    flex(用 flexbox froggy 去学或者阮一峰的博客去学)
两栏布局
水平居中
    inline 的水平居中
    block 的水平居中
垂直居中
    有完整的套路
    父节点为 position: relative;
    自己为
    position: absolute;
    top: 50%;
    transform: translateY(-50%);

居中的完整套路(感兴趣可以看看)
https://css-tricks.com/centering-css-complete-guide/

flexbox froggy
响应式设计
移动开发
    主要是微信网页开发




JS 部分
值类型与引用类型
//
var a = {
    v: 1
}
var b = a
console.log(b.v)
// 1

a.v = 2
console.log(b.v)
// 2

a = {
    v: 3
}
console.log(b.v)
// 2




// 变量声明提升(这是一个特性)
// 这段代码
function f1() {
    console.log(a)
    var a = 1
}
f1()
// 相当于
function f1() {
    var a
    console.log(a)
    a = 1
}
f1()



// 这段代码
console.log(b())
function b() {
    return 2
}
// 相当于
var b = function() {
    return 2
}
console.log(b())


// 这段代码
console.log(c())
var c = function() {
    return 3
}
// 相当于
var c
console.log(c())
c = function() {
    return 3
}
// 所以 console.log 会报错, 因为 c 在那个函数还不是一个函数, 只是 undefined


// 注意，let 或者 const 声明的变量不具备 变量声明提升 的特性
console.log(d)
let d = 4




// this
//
var x = 0
function test() {
    console.log(this.x)
}
var o = {}
o.x = 1
o.m = test
o.m()       // 1
o['m']()    // 1
o.m.apply()
// apply 请看 apply bind call this 那节课


// this + arguments
var gua = 'name 001'
var foo = function() {
    // arguments 并不是数组, 只是行为恰好和数组一样,
    // 一般称为奇异对象或者类数组对象(NodeList 也是这样的对象)
    console.log('arguments', arguments, arguments.gua)
    var r = arguments['0']()
    console.log(r)
    // console.log(arguments[0]())
}

var o = {}
o.gua = 'name 000'
o.func = foo
o.func(function() {
    console.log('this in function', this)
    return this.gua
})

o.func2 = function(){
    arguments.gua = 'gua'
    console.log(arguments[0]())
}

o.func2(function(){
    return this.gua
})


// prototype
// prototype 考察较多的是原型链
//
function Foo() {
    this.name = 'a'
}

var f1 = new Foo()
f1.name = 'b'
console.log(f1.name)

var f2 = new Foo()
console.log(f2.name)






arguments
//
(function() {
    return typeof arguments
})()
(function() {
    console.log(arguments)
})(1, 2, 3)

(function(...args) {
    console.log(args)
})(1, 2, 3)



call, apply, bind
// call, apply 和 bind 的区别

setTimeout 和 setInterval
// 两者的区别

setTimeout 与循环结合
// 下面的输出全是 5, 因为引用的是 i 这个变量
// 引用的 i 可以在函数内部访问到这件事称之为 闭包
for (var i = 0; i < 5; i++) {
    setTimeout(function() {
        console.log(new Date(), i)
    }, 1000)
}
console.log(new Date(), i)


// 皇帝的闭包问题
// 这根本不是闭包的问题
// 因为 setTimeout 即便第二个参数是 0 也会在循环结束之后才执行函数
// 所以 5 个输出全都是 5
for (var i = 0; i < 5; i++) {
    setTimeout((function() {
        console.log(new Date(), i)
    })(), 0)
}

for (let i = 0; i < 5; i++) {
    setTimeout(function() {
        console.log(new Date(), i)
    }, 0)
}

let i = 0
for (; i < 5; i++) {
    setTimeout(function() {
        console.log(new Date(), i)
    }, 0)
}



事件冒泡, 事件捕获, 事件委托
// 讲清楚这三个概念

闭包
// 所谓经典的闭包面试题(上面讲过的皇帝的闭包问题)
// 使用闭包实现如下程序
// 函数每调用一次，该函数的返回值加 1
var foo = function() {
    var i = 0
    return function() {
        i++
        return i
    }
}
var a = foo()
a()
a()

clone 和 deepClone
// 实现 clone 和 deepClone 函数
// 用 JSON.stringify 和 JSON.parse 实现 deepClone 是一个很有新意的方式

ajax（可能需要手写原生的 ajax）
// 实现原生的 ajax 函数
// readyState 0 1 2 3 4 各代表什么含义



HTTP 请求方法, 常见状态码, 头部常见字段
// HTTP 有哪些常见请求方法 GET POST PUT PATCH DELETE
// HTTP 常见状态码有哪些 200 301 302 403 404 500 502
// HTTP 头部常见字段有哪些
    Content-Type        application/json
    Content-Length


跨域 （jsonp, postMessage, cors, 用服务器(比如 node)转发请求和响应）
// 跨域有哪些常见的解决方式

网络安全: xss, csrf
// xss 和 csrf 的原理是什么

DOM 操作（查找, 添加, 删除, 修改）
// DOM 查找/添加/删除/修改对应的 API 是什么

jQuery 常见 API
// jQuery 常见 API
如果感兴趣, 就阅读 jquery 基础教程 前六章




数据结构
数组
对象
队列
栈
数组、对象、字符串的相互转化
比如 a=1&b=2&c=3 怎样转成对象, 复习基础课程的作业就可以
// 有这样一个 url： http://vip.qq.com/a.java?a=1&b=2&c=3&d=xxx&e
// 写一段 JS 程序将 url 的参数转成对象的形式
{
    a: 1,
    b: 2,
    c: 3,
    d: 'xxx',
    e: '',
}




ES6
ES6 的面试题一般是概念性质的, 所以清楚下面的概念就可以了
let 和 const, 有一个 TDZ（暂时性死区的概念，了解下即可）
箭头函数
解构
剩余参数(扩展符号)
Promise, 可能会附带 async await
class
Set

// 用解构来简化参数列表
var gua = function({name, height}){
    console.log(name, height)
}
var gua2 = function(info){
    console.log(info.name, info.height)
}

var info = {
    name: 'gua',
    height: 169,
}

gua(info)


React
// React 也是概念性质的题目为主, 基本上不会考察写代码
React Angular 这 2 个一般只会一个就可以的, 所以这里只说 React 的情况
react 的广告
virtual dom
diff 算法的原理
state 和 props
组件生命周期
组件通信：父组件 -> 子组件, 子组件 -> 父组件, A 组件 -> B 组件
React Router（react 路由）
Redux/MobX(react 的状态(state)管理方案)
react ui 有两套很流行: Material UI 和 Ant Design, 国内流行的是 Ant Design
